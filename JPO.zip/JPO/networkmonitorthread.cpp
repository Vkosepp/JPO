#include "networkmonitorthread.h"
#include <QNetworkRequest>
#include <QDebug>
#include <QRandomGenerator>

NetworkMonitorThread::NetworkMonitorThread(QObject *parent) : QObject(parent) {
    m_isNetworkAvailable = false;
    m_consecutiveFailures = 0;
    m_checkInterval = 10000; // Default 10 seconds
    m_networkManager = nullptr;
    m_checkTimer = nullptr;
    m_taskProcessingTimer = nullptr;

    // We don't immediately initialize to allow proper thread setup
    // initialize() should be called after the object is moved to its proper thread
}

NetworkMonitorThread::~NetworkMonitorThread() {
    stopMonitoring();
    delete m_networkManager;
    delete m_checkTimer;
    delete m_taskProcessingTimer;
}

void NetworkMonitorThread::initialize() {
    // Create objects that need an event loop
    m_networkManager = new QNetworkAccessManager(this);
    m_checkTimer = new QTimer(this);
    m_taskProcessingTimer = new QTimer(this);

    // Connect the timers
    connect(m_checkTimer, &QTimer::timeout, this, &NetworkMonitorThread::onCheckTimerTimeout);
    connect(m_taskProcessingTimer, &QTimer::timeout, this, &NetworkMonitorThread::processPendingTasks);

    // Connect network manager signals
    connect(m_networkManager, &QNetworkAccessManager::finished,
            this, &NetworkMonitorThread::onNetworkRequestFinished);

    // Initialize network stats map
    m_networkStats["totalChecks"] = 0;
    m_networkStats["successfulChecks"] = 0;
    m_networkStats["failedChecks"] = 0;
    m_networkStats["averageResponseTime"] = 0.0;
    m_networkStats["lastResponseTime"] = 0;
    m_networkStats["lastCheckTime"] = "";
    m_networkStats["lastStatus"] = false;
    m_networkStats["consecutiveFailures"] = 0;
    m_networkStats["lastSuccessfulCheckTime"] = "";
}

void NetworkMonitorThread::startMonitoring(int intervalMs) {
    QMutexLocker locker(&m_mutex);

    // Ensure objects are initialized
    if (!m_checkTimer || !m_taskProcessingTimer || !m_networkManager) {
        qWarning() << "NetworkMonitorThread not initialized. Call initialize() first.";
        return;
    }

    m_checkInterval = intervalMs;

    // Zatrzymaj timer, jeśli już działa
    if (m_checkTimer->isActive()) {
        m_checkTimer->stop();
    }

    // Ustaw nowy interwał i uruchom timer
    m_checkTimer->setInterval(m_checkInterval);
    m_checkTimer->start();

    // Natychmiast sprawdź połączenie
    checkConnection();

    // Uruchom timer do przetwarzania zadań w kolejce
    m_taskProcessingTimer->setInterval(5000); // Co 5 sekund sprawdzaj zadania w kolejce
    m_taskProcessingTimer->start();
}

void NetworkMonitorThread::stopMonitoring() {
    QMutexLocker locker(&m_mutex);

    if (m_checkTimer && m_checkTimer->isActive()) {
        m_checkTimer->stop();
    }

    if (m_taskProcessingTimer && m_taskProcessingTimer->isActive()) {
        m_taskProcessingTimer->stop();
    }
}

void NetworkMonitorThread::checkConnection() {
    QMutexLocker locker(&m_mutex);

    // Ensure objects are initialized
    if (!m_networkManager) {
        qWarning() << "NetworkMonitorThread not initialized. Call initialize() first.";
        return;
    }

    try {
        // Sprawdzenie połączenia z głównym API
        QUrl url(m_testEndpoint);
        QNetworkRequest request(url);
        request.setAttribute(QNetworkRequest::CacheLoadControlAttribute, QNetworkRequest::AlwaysNetwork);

        QDateTime startTime = QDateTime::currentDateTime();
        request.setHeader(QNetworkRequest::UserAgentHeader, "AirQualityApp NetworkMonitor");

        // Dodanie znacznika czasu do żądania, aby uniknąć pamięci podręcznej
        request.setAttribute(QNetworkRequest::CustomVerbAttribute, "CHECK_CONNECTION");
        request.setAttribute(QNetworkRequest::UserMax, QVariant::fromValue(startTime));

        m_networkManager->get(request);
    }
    catch (const std::exception &e) {
        emit networkError(QString("Błąd podczas sprawdzania połączenia: %1").arg(e.what()));
    }
}

void NetworkMonitorThread::checkSpecificEndpoint(const QString &endpoint)
{
    QMutexLocker locker(&m_mutex);

    try {
        QUrl url(endpoint);
        QNetworkRequest request(url);
        request.setAttribute(QNetworkRequest::CacheLoadControlAttribute, QNetworkRequest::AlwaysNetwork);

        QDateTime startTime = QDateTime::currentDateTime();
        request.setHeader(QNetworkRequest::UserAgentHeader, "AirQualityApp EndpointCheck");

        request.setAttribute(QNetworkRequest::CustomVerbAttribute, "CHECK_ENDPOINT");
        request.setAttribute(QNetworkRequest::UserMax, QVariant::fromValue(startTime));
        request.setAttribute(QNetworkRequest::User, QVariant::fromValue(endpoint));

        m_networkManager->get(request);
    }
    catch (const std::exception &e) {
        emit networkError(QString("Błąd podczas sprawdzania endpointu: %1").arg(e.what()));
    }
}

void NetworkMonitorThread::testConnectionSpeed()
{
    QMutexLocker locker(&m_mutex);

    try {
        // Testujemy prędkość pobierając plik o znanym rozmiarze
        // Przykładowy endpoint do testu - powinien być zastąpiony rzeczywistym URL
        QString speedTestUrl = "https://api.gios.gov.pl/pjp-api/rest/data/getData/1465?timestamp=" +
                               QString::number(QDateTime::currentMSecsSinceEpoch());

        QUrl url(speedTestUrl);
        QNetworkRequest request(url);
        request.setAttribute(QNetworkRequest::CacheLoadControlAttribute, QNetworkRequest::AlwaysNetwork);

        m_speedTestStartTime = QDateTime::currentDateTime();
        request.setHeader(QNetworkRequest::UserAgentHeader, "AirQualityApp SpeedTest");

        request.setAttribute(QNetworkRequest::CustomVerbAttribute, "SPEED_TEST");

        m_networkManager->get(request);
    }
    catch (const std::exception &e) {
        emit networkError(QString("Błąd podczas testu prędkości: %1").arg(e.what()));
    }
}

void NetworkMonitorThread::queueTaskWhenOnline(const QString &taskType, const QVariantMap &taskData)
{
    QMutexLocker locker(&m_mutex);

    try {
        // Dodaj zadanie do kolejki
        m_pendingTasks.enqueue(qMakePair(taskType, taskData));

        // Jeśli sieć jest dostępna, przetwórz zadania od razu
        if (m_isNetworkAvailable) {
            processPendingTasks();
        }
    }
    catch (const std::exception &e) {
        emit networkError(QString("Błąd podczas dodawania zadania do kolejki: %1").arg(e.what()));
    }
}

void NetworkMonitorThread::onNetworkRequestFinished(QNetworkReply *reply)
{
    QMutexLocker locker(&m_mutex);

    try {
        QNetworkRequest request = reply->request();
        QString requestType = request.attribute(QNetworkRequest::CustomVerbAttribute).toString();

        if (requestType == "CHECK_CONNECTION") {
            QDateTime startTime = request.attribute(QNetworkRequest::UserMax).toDateTime();
            int responseTime = startTime.msecsTo(QDateTime::currentDateTime());

            bool oldStatus = m_isNetworkAvailable;
            bool newStatus = (reply->error() == QNetworkReply::NoError);

            m_isNetworkAvailable = newStatus;

            // Aktualizacja statystyk
            updateNetworkStats(newStatus, responseTime);

            // Jeśli status się zmienił, powiadom o tym
            if (oldStatus != newStatus) {
                emit networkStatusChanged(newStatus);

                if (newStatus) {
                    // Sieć jest ponownie dostępna, zresetuj licznik niepowodzeń
                    m_consecutiveFailures = 0;
                    m_lastSuccessfulCheck = QDateTime::currentDateTime();

                    // Przetwórz zadania oczekujące w kolejce
                    processPendingTasks();
                }
            }

            // Zwiększ licznik niepowodzeń, jeśli sprawdzenie nie powiodło się
            if (!newStatus) {
                m_consecutiveFailures++;

                // Jeśli mamy wiele niepowodzeń z rzędu, zwiększ interwał sprawdzania
                if (m_consecutiveFailures > 3) {
                    int newInterval = qMin(m_checkInterval * 2, 60000); // Max 1 minuta
                    if (newInterval != m_checkInterval) {
                        m_checkInterval = newInterval;
                        m_checkTimer->setInterval(m_checkInterval);
                    }
                }
            } else {
                // Jeśli sprawdzenie się powiodło, a wcześniej był zwiększony interwał, zmniejsz go
                if (m_checkInterval > 10000) {
                    m_checkInterval = 10000; // Przywróć domyślny interwał
                    m_checkTimer->setInterval(m_checkInterval);
                }
            }
        }
        else if (requestType == "CHECK_ENDPOINT") {
            QDateTime startTime = request.attribute(QNetworkRequest::UserMax).toDateTime();
            QString endpoint = request.attribute(QNetworkRequest::User).toString();
            int responseTime = startTime.msecsTo(QDateTime::currentDateTime());

            bool isAvailable = (reply->error() == QNetworkReply::NoError);

            emit specificEndpointStatus(endpoint, isAvailable, responseTime);
        }
        else if (requestType == "SPEED_TEST") {
            if (reply->error() == QNetworkReply::NoError) {
                QByteArray data = reply->readAll();
                QDateTime endTime = QDateTime::currentDateTime();
                int elapsedMs = m_speedTestStartTime.msecsTo(endTime);

                if (elapsedMs > 0 && !data.isEmpty()) {
                    // Obliczanie prędkości w Kbps (kilobity na sekundę)
                    double sizeKb = data.size() * 8.0 / 1024.0;
                    double speedKbps = sizeKb / (elapsedMs / 1000.0);

                    emit connectionSpeedMeasured(speedKbps);

                    // Dodaj informację o prędkości do statystyk
                    m_networkStats["lastSpeedKbps"] = speedKbps;
                    m_networkStats["lastSpeedTest"] = QDateTime::currentDateTime().toString(Qt::ISODate);

                    emit networkStats(m_networkStats);
                }
            } else {
                emit networkError("Test prędkości nie powiódł się: " + reply->errorString());
            }
        }

        reply->deleteLater();
    }
    catch (const std::exception &e) {
        emit networkError(QString("Błąd podczas przetwarzania odpowiedzi sieciowej: %1").arg(e.what()));
        reply->deleteLater();
    }
}

void NetworkMonitorThread::onLookupFinished(const QHostInfo &hostInfo)
{
    QMutexLocker locker(&m_mutex);

    try {
        bool success = (hostInfo.error() == QHostInfo::NoError);

        // Aktualizacja statusu sieci
        bool oldStatus = m_isNetworkAvailable;
        m_isNetworkAvailable = success;

        // Jeśli status się zmienił, powiadom o tym
        if (oldStatus != success) {
            emit networkStatusChanged(success);

            if (success) {
                // Przetwórz zadania oczekujące w kolejce
                processPendingTasks();
            }
        }
    }
    catch (const std::exception &e) {
        emit networkError(QString("Błąd podczas przetwarzania wyniku wyszukiwania hosta: %1").arg(e.what()));
    }
}

void NetworkMonitorThread::onSpeedTestFinished()
{
    // Obsługa zakończenia testu prędkości, jeśli potrzebna
}

void NetworkMonitorThread::onCheckTimerTimeout()
{
    checkConnection();
}

void NetworkMonitorThread::processPendingTasks()
{
    QMutexLocker locker(&m_mutex);

    try {
        // Jeśli nie ma połączenia z siecią, nie przetwarzaj zadań
        if (!m_isNetworkAvailable) {
            return;
        }

        // Przetwórz oczekujące zadania
        while (!m_pendingTasks.isEmpty()) {
            QPair<QString, QVariantMap> task = m_pendingTasks.dequeue();
            executeTask(task.first, task.second);
        }
    }
    catch (const std::exception &e) {
        emit networkError(QString("Błąd podczas przetwarzania zadań w kolejce: %1").arg(e.what()));
    }
}

void NetworkMonitorThread::updateNetworkStats(bool isSuccess, int responseTimeMs)
{
    m_networkStats["totalChecks"] = m_networkStats["totalChecks"].toInt() + 1;

    if (isSuccess) {
        m_networkStats["successfulChecks"] = m_networkStats["successfulChecks"].toInt() + 1;
    } else {
        m_networkStats["failedChecks"] = m_networkStats["failedChecks"].toInt() + 1;
    }

    // Aktualizacja średniego czasu odpowiedzi
    if (isSuccess && responseTimeMs > 0) {
        int totalChecks = m_networkStats["successfulChecks"].toInt();
        double oldAvg = m_networkStats["averageResponseTime"].toDouble();

        if (totalChecks > 1) {
            // Obliczanie nowej średniej
            double newAvg = oldAvg + (responseTimeMs - oldAvg) / totalChecks;
            m_networkStats["averageResponseTime"] = newAvg;
        } else {
            m_networkStats["averageResponseTime"] = responseTimeMs;
        }

        m_networkStats["lastResponseTime"] = responseTimeMs;
    }

    m_networkStats["lastCheckTime"] = QDateTime::currentDateTime().toString(Qt::ISODate);
    m_networkStats["lastStatus"] = isSuccess;
    m_networkStats["consecutiveFailures"] = m_consecutiveFailures;

    if (isSuccess) {
        m_networkStats["lastSuccessfulCheckTime"] = QDateTime::currentDateTime().toString(Qt::ISODate);
    }

    emit networkStats(m_networkStats);
}

void NetworkMonitorThread::executeTask(const QString &taskType, const QVariantMap &taskData)
{
    bool success = false;

    try {
        // Emituj sygnał, który zostanie obsłużony przez odpowiedni wątek
        emit executeQueuedTask(taskType, taskData);
        success = true;
    }
    catch (const std::exception &e) {
        emit networkError(QString("Błąd podczas wykonywania zadania: %1").arg(e.what()));
    }

    emit taskExecuted(taskType, taskData, success);
}
