#include "workerthread.h"
#include <QDebug>
#include <QTimer>
#include <QDateTime>
#include <QFile>
#include <QUrlQuery>
#include <QTimer>

WorkerThread::WorkerThread(QObject *parent) : QObject(parent), m_networkManager(new QNetworkAccessManager(this)) {
    connect(m_networkManager, &QNetworkAccessManager::finished, this, &WorkerThread::onNetworkReply);
    m_isNetworkAvailable = false;
    m_pendingSensors = 0;
    m_networkManager = nullptr;
    m_networkCheckTimer = nullptr;

    // Utwórz timer dla sprawdzania statusu sieci
    m_networkCheckTimer = new QTimer(this);
    connect(m_networkCheckTimer, &QTimer::timeout, this, &WorkerThread::checkNetworkConnection);
    m_networkCheckTimer->start(10000); // Sprawdzaj co 10 sekund
}

// Fix the destructor:
WorkerThread::~WorkerThread() {
    // Zatrzymaj timer
    if (m_networkCheckTimer) {
        m_networkCheckTimer->stop();
    }
}

void WorkerThread::initialize() {
    qDebug() << "WorkerThread initialized in thread:" << QThread::currentThreadId();

    // Inicjalizacja menedżera sieci
    m_networkManager = new QNetworkAccessManager(this);
    connect(m_networkManager, &QNetworkAccessManager::finished, this, &WorkerThread::onNetworkReply);

    // Inicjalizacja timera do sprawdzania sieci
    m_networkCheckTimer = new QTimer(this);
    connect(m_networkCheckTimer, &QTimer::timeout, this, &WorkerThread::checkNetworkConnection);
    m_networkCheckTimer->start(10000); // co 10 sekund
}

void WorkerThread::setup()
{
    // Create objects that need an event loop
    m_networkManager = new QNetworkAccessManager(this);
    m_networkCheckTimer = new QTimer(this);

    // Connect the timer
    connect(m_networkCheckTimer, &QTimer::timeout, this, &WorkerThread::checkNetworkConnection);

    // Start the timer
    m_networkCheckTimer->start(30000); // 30 seconds

    // Do an initial network check
    checkNetworkConnection();
}

void WorkerThread::fetchStations(const QString &city) {
    // Zapisz miasto w zmiennej członkowskiej
    if (!m_networkManager) {
        emit networkError("Network manager not initialized");
        return;
    }

    QMutexLocker locker(&m_mutex);
    m_currentCity = city;
    locker.unlock();

    QUrl url("https://api.gios.gov.pl/pjp-api/rest/station/findAll");
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QNetworkReply *reply = m_networkManager->get(request);

    connect(reply, &QNetworkReply::errorOccurred, this, [this, reply](QNetworkReply::NetworkError error) {
        QString errorString = "Błąd sieci: " + reply->errorString();
        qDebug() << "Network error:" << error << reply->errorString();

        // Sprawdź czy to problem z połączeniem
        if (error == QNetworkReply::NetworkError::ConnectionRefusedError ||
            error == QNetworkReply::NetworkError::HostNotFoundError ||
            error == QNetworkReply::NetworkError::TimeoutError ||
            error == QNetworkReply::NetworkError::UnknownNetworkError) {

            m_isNetworkAvailable = false;
            emit networkStatusChanged(false);
        }

        emit stationsError(errorString);
    });
}

void WorkerThread::onNetworkReply(QNetworkReply *reply) {
    // Ten slot obsługuje tylko odpowiedzi związane z listą stacji
    QString requestUrl = reply->request().url().toString();
    if (!requestUrl.contains("findAll")) {
        // To nie jest odpowiedź dla listy stacji, ignorujemy
        reply->deleteLater();
        return;
    }

    if (reply->error() != QNetworkReply::NoError) {
        emit stationsError("Błąd podczas pobierania danych: " + reply->errorString());
        reply->deleteLater();
        return;
    }

    // Parsowanie odpowiedzi JSON
    QByteArray responseData = reply->readAll();
    processStationsResponse(responseData);

    reply->deleteLater();
}

void WorkerThread::processStationsResponse(const QByteArray &responseData) {
    QJsonParseError parseError;
    QJsonDocument doc = QJsonDocument::fromJson(responseData, &parseError);

    if (parseError.error != QJsonParseError::NoError) {
        emit stationsError("Błąd parsowania JSON: " + parseError.errorString());
        return;
    }

    QJsonArray stationsArray = doc.array();
    QVariantList stations;
    bool found = false;

    // Pobierz miasto z mutex-protected zmiennej
    QMutexLocker locker(&m_mutex);
    QString currentCity = m_currentCity;
    locker.unlock();

    // Wyszukiwanie stacji dla wybranego miasta
    for (const QJsonValue &value : stationsArray) {
        QJsonObject station = value.toObject();
        QJsonObject city = station["city"].toObject();
        QString cityName = city["name"].toString();

        if (cityName.toLower() == currentCity.toLower()) {
            found = true;
            QVariantMap stationData;
            stationData["stationId"] = station["id"].toInt();
            stationData["stationName"] = station["stationName"].toString();
            stationData["lat"] = station["gegrLat"].toString();
            stationData["lon"] = station["gegrLon"].toString();
            stationData["address"] = station["addressStreet"].toString();
            stations.append(stationData);
        }
    }

    // Emituj wyniki
    if (!found) {
        emit stationsError("Nie znaleziono stacji w " + currentCity + ".");
    } else {
        emit stationsReady(stations, currentCity);
    }
}

void WorkerThread::fetchSensorData(int stationId) {
    // Czyszczenie poprzednich danych
    QMutexLocker locker(&m_mutex);
    m_sensorData.clear();
    m_pendingSensors = 0;
    locker.unlock();

    QUrl url("https://api.gios.gov.pl/pjp-api/rest/station/sensors/" + QString::number(stationId));
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    qDebug() << "Fetching sensor data from URL:" << url.toString();

    QNetworkReply *reply = m_networkManager->get(request);

    connect(reply, &QNetworkReply::errorOccurred, this, [this, reply](QNetworkReply::NetworkError error) {
        QString errorString = "Błąd pobierania danych sensorów: " + reply->errorString();
        qDebug() << "Sensor data network error:" << error << reply->errorString();
        emit sensorDataError(errorString);
    });

    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        if (reply->error() == QNetworkReply::NoError) {
            this->onSensorDataReply(reply);
        } else {
            reply->deleteLater();
        }
    });

    // Pobierz również indeks jakości powietrza dla tej stacji
    fetchAirQualityIndex(stationId);
}

void WorkerThread::onSensorDataReply(QNetworkReply *reply) {
    // Odczyt danych odpowiedzi
    QByteArray responseData = reply->readAll();

    qDebug() << "Sensor data response:" << QString(responseData);

    if (responseData.isEmpty()) {
        emit sensorDataError("Otrzymano pustą odpowiedź od serwera");
        reply->deleteLater();
        return;
    }

    QJsonParseError parseError;
    QJsonDocument doc = QJsonDocument::fromJson(responseData, &parseError);

    if (parseError.error != QJsonParseError::NoError) {
        emit sensorDataError("Błąd parsowania JSON sensorów: " + parseError.errorString());
        reply->deleteLater();
        return;
    }

    QJsonArray sensorsArray = doc.array();

    // Sprawdzenie czy mamy sensory do przetworzenia
    QMutexLocker locker(&m_mutex);
    m_pendingSensors = sensorsArray.size();
    locker.unlock();

    if (sensorsArray.size() == 0) {
        emit sensorDataError("Nie znaleziono sensorów dla tej stacji");
        reply->deleteLater();
        return;
    }

    // Przetwarzanie każdego sensora
    for (const QJsonValue &value : sensorsArray) {
        QJsonObject sensor = value.toObject();
        int sensorId = sensor["id"].toInt();

        // Przetwarzanie parametrów sensora
        QJsonObject param = sensor["param"].toObject();
        QString paramName = param["paramName"].toString();
        QString paramFormula = param["paramFormula"].toString();
        QString paramCode = param["paramCode"].toString();

        qDebug() << "Found sensor:" << sensorId << paramName << paramFormula << paramCode;

        // Żądanie danych dla tego sensora
        QUrl url("https://api.gios.gov.pl/pjp-api/rest/data/getData/" + QString::number(sensorId));
        QNetworkRequest request(url);
        request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

        QNetworkReply *dataReply = m_networkManager->get(request);

        connect(dataReply, &QNetworkReply::errorOccurred, this, [dataReply](QNetworkReply::NetworkError error) {
            qDebug() << "Measurement data network error:" << error << dataReply->errorString();
        });

        connect(dataReply, &QNetworkReply::finished, this, [this, dataReply, sensorId, paramName, paramFormula, paramCode]() {
            if (dataReply->error() == QNetworkReply::NoError) {
                this->onMeasurementDataReply(dataReply, sensorId, paramName, paramFormula, paramCode);
            } else {
                // Liczymy to jako przetworzone nawet jeśli wystąpił błąd
                QMutexLocker locker(&m_mutex);
                m_pendingSensors--;

                if (m_pendingSensors <= 0) {
                    QVariantList sensorDataCopy = m_sensorData;
                    locker.unlock();
                    emit sensorDataReady(sensorDataCopy);
                } else {
                    locker.unlock();
                }

                dataReply->deleteLater();
            }
        });
    }

    reply->deleteLater();
}

void WorkerThread::onMeasurementDataReply(QNetworkReply *reply, int sensorId, const QString &paramName,
                                          const QString &paramFormula, const QString &paramCode) {
    QVariantMap sensorDataMap;
    sensorDataMap["sensorId"] = sensorId;
    sensorDataMap["paramName"] = paramName;
    sensorDataMap["paramFormula"] = paramFormula;
    sensorDataMap["paramCode"] = paramCode;
    sensorDataMap["hasValue"] = false;

    QByteArray responseData = reply->readAll();
    qDebug() << "Measurement data for sensor" << sensorId << ":" << QString(responseData.left(200)) + "...";

    QJsonParseError parseError;
    QJsonDocument doc = QJsonDocument::fromJson(responseData, &parseError);

    if (parseError.error == QJsonParseError::NoError) {
        QJsonObject dataObj = doc.object();

        if (dataObj.contains("values") && dataObj["values"].isArray()) {
            QJsonArray values = dataObj["values"].toArray();

            for (const QJsonValue &value : values) {
                QJsonObject measurement = value.toObject();
                // Szukamy pierwszego niepustego pomiaru
                if (!measurement["value"].isNull()) {
                    sensorDataMap["date"] = measurement["date"].toString();
                    sensorDataMap["value"] = measurement["value"].toDouble();
                    sensorDataMap["hasValue"] = true;
                    break;
                }
            }
        }
    } else {
        qDebug() << "JSON parse error for sensor" << sensorId << ":" << parseError.errorString();
    }

    // Dodaj do listy wyników i sprawdź czy to ostatni sensor
    QMutexLocker locker(&m_mutex);
    m_sensorData.append(sensorDataMap);
    m_pendingSensors--;

    if (m_pendingSensors <= 0) {
        QVariantList sensorDataCopy = m_sensorData;
        locker.unlock();
        emit sensorDataReady(sensorDataCopy);
    } else {
        locker.unlock();
    }

    reply->deleteLater();
}

void WorkerThread::fetchAirQualityIndex(int stationId) {
    QUrl url("https://api.gios.gov.pl/pjp-api/rest/aqindex/getIndex/" + QString::number(stationId));
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QNetworkReply *reply = m_networkManager->get(request);

    connect(reply, &QNetworkReply::errorOccurred, this, [this, reply](QNetworkReply::NetworkError error) {
        qDebug() << "Air quality index network error:" << error << reply->errorString();
        emit airQualityIndexError(reply->errorString());
    });

    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        if (reply->error() == QNetworkReply::NoError) {
            this->onAirQualityIndexReply(reply);
        } else {
            reply->deleteLater();
        }
    });
}

void WorkerThread::onAirQualityIndexReply(QNetworkReply *reply) {
    QByteArray responseData = reply->readAll();
    qDebug() << "Air quality index response:" << QString(responseData.left(200)) + "...";

    QJsonParseError parseError;
    QJsonDocument doc = QJsonDocument::fromJson(responseData, &parseError);

    if (parseError.error != QJsonParseError::NoError) {
        qDebug() << "JSON parse error for air quality index:" << parseError.errorString();
        emit airQualityIndexError(parseError.errorString());
        reply->deleteLater();
        return;
    }

    QJsonObject aqiObj = doc.object();
    QVariantMap airQualityIndex;

    if (!aqiObj.isEmpty()) {
        // Pobierz ogólny indeks jakości powietrza
        if (aqiObj.contains("stIndexLevel") && !aqiObj["stIndexLevel"].isNull()) {
            QJsonObject indexLevel = aqiObj["stIndexLevel"].toObject();
            airQualityIndex["indexLevelName"] = indexLevel["indexLevelName"].toString();
            airQualityIndex["id"] = indexLevel["id"].toInt();
        } else {
            airQualityIndex["indexLevelName"] = "Brak danych";
        }

        // Pobierz daty obliczeń
        airQualityIndex["calcDate"] = aqiObj["stCalcDate"].toString();
        airQualityIndex["indexCalcDate"] = aqiObj["stIndexCalcDate"].toString();

        // Pobierz indeksy dla poszczególnych zanieczyszczeń
        if (aqiObj.contains("pm10IndexLevel") && !aqiObj["pm10IndexLevel"].isNull()) {
            QJsonObject pm10Index = aqiObj["pm10IndexLevel"].toObject();
            airQualityIndex["pm10IndexName"] = pm10Index["indexLevelName"].toString();
        }

        if (aqiObj.contains("pm25IndexLevel") && !aqiObj["pm25IndexLevel"].isNull()) {
            QJsonObject pm25Index = aqiObj["pm25IndexLevel"].toObject();
            airQualityIndex["pm25IndexName"] = pm25Index["indexLevelName"].toString();
        }

        if (aqiObj.contains("o3IndexLevel") && !aqiObj["o3IndexLevel"].isNull()) {
            QJsonObject o3Index = aqiObj["o3IndexLevel"].toObject();
            airQualityIndex["o3IndexName"] = o3Index["indexLevelName"].toString();
        }

        if (aqiObj.contains("no2IndexLevel") && !aqiObj["no2IndexLevel"].isNull()) {
            QJsonObject no2Index = aqiObj["no2IndexLevel"].toObject();
            airQualityIndex["no2IndexName"] = no2Index["indexLevelName"].toString();
        }

        if (aqiObj.contains("so2IndexLevel") && !aqiObj["so2IndexLevel"].isNull()) {
            QJsonObject so2Index = aqiObj["so2IndexLevel"].toObject();
            airQualityIndex["so2IndexName"] = so2Index["indexLevelName"].toString();
        }

        emit airQualityIndexReady(airQualityIndex);
    }

    reply->deleteLater();
}

void WorkerThread::fetchHistoricalData(int sensorId, const QString &paramCode) {
    // Wyczyść poprzednie dane
    QMutexLocker locker(&m_mutex);
    m_historicalData.clear();
    locker.unlock();

    QUrl url("https://api.gios.gov.pl/pjp-api/rest/data/getData/" + QString::number(sensorId));
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    qDebug() << "Fetching historical data from URL:" << url.toString();

    QNetworkReply *reply = m_networkManager->get(request);

    connect(reply, &QNetworkReply::errorOccurred, this, [this, reply](QNetworkReply::NetworkError error) {
        QString errorString = "Błąd pobierania danych historycznych: " + reply->errorString();
        qDebug() << "Historical data network error:" << error << reply->errorString();
        emit historicalDataError(errorString);
    });

    connect(reply, &QNetworkReply::finished, this, [this, reply, sensorId, paramCode]() {
        if (reply->error() == QNetworkReply::NoError) {
            this->onHistoricalDataReply(reply, sensorId, paramCode);
        } else {
            reply->deleteLater();
        }
    });
}

void WorkerThread::onHistoricalDataReply(QNetworkReply *reply, int /* sensorId */, const QString &paramCode) {
    QByteArray responseData = reply->readAll();
    qDebug() << "Historical data response:" << QString(responseData.left(200)) + "...";

    QJsonParseError parseError;
    QJsonDocument doc = QJsonDocument::fromJson(responseData, &parseError);

    if (parseError.error != QJsonParseError::NoError) {
        emit historicalDataError("Błąd parsowania danych historycznych: " + parseError.errorString());
        reply->deleteLater();
        return;
    }

    QJsonObject dataObj = doc.object();
    QVariantList historicalData;

    if (dataObj.contains("values") && dataObj["values"].isArray()) {
        QJsonArray values = dataObj["values"].toArray();

        // Process values (reverse order to get chronological order)
        for (int i = values.size() - 1; i >= 0; i--) {
            QJsonObject measurement = values[i].toObject();

            // Skip null values
            if (!measurement["value"].isNull()) {
                QVariantMap dataPoint;
                QString dateStr = measurement["date"].toString();

                // Formatowanie daty i czasu dla wykresu
                QDateTime dateTime = QDateTime::fromString(dateStr, Qt::ISODate);

                dataPoint["date"] = dateStr;
                dataPoint["formattedDate"] = dateTime.toString("dd.MM.yyyy");
                dataPoint["formattedTime"] = dateTime.toString("HH:mm");
                dataPoint["displayTime"] = dateTime.toString("dd.MM HH:mm");

                dataPoint["value"] = measurement["value"].toDouble();
                dataPoint["paramCode"] = paramCode;

                historicalData.append(dataPoint);
            }
        }

        QMutexLocker locker(&m_mutex);
        m_historicalData = historicalData;
        locker.unlock();

        if (historicalData.isEmpty()) {
            emit historicalDataError("Brak danych pomiarowych dla wybranego parametru");
        } else {
            emit historicalDataReady(historicalData);
            // Oblicz statystyki w osobnym wątku
            calculateStats(historicalData);
        }
    } else {
        emit historicalDataError("Nieprawidłowy format danych historycznych");
    }

    reply->deleteLater();
}

void WorkerThread::calculateStats(const QVariantList &historicalData) {
    if (historicalData.isEmpty()) {
        return;
    }

    double sum = 0;
    double min = std::numeric_limits<double>::max();
    double max = std::numeric_limits<double>::lowest();
    QDateTime firstDate;
    QDateTime lastDate;

    // Process all values to find min, max, and calculate average
    for (int i = 0; i < historicalData.size(); i++) {
        QVariantMap dataPoint = historicalData[i].toMap();
        double value = dataPoint["value"].toDouble();

        // Update min and max
        if (value < min) min = value;
        if (value > max) max = value;

        // Add to sum for average calculation
        sum += value;

        // Track first and last dates
        QString dateStr = dataPoint["date"].toString();
        QDateTime date = QDateTime::fromString(dateStr, Qt::ISODate);

        if (i == 0) {
            firstDate = date;
        }
        if (i == historicalData.size() - 1) {
            lastDate = date;
        }
    }

    // Calculate average
    double average = sum / historicalData.size();

    // Analiza trendu (regresja liniowa)
    double trendSlope = 0;
    QString trendDirection = "stabilny";

    if (historicalData.size() > 1) {
        // Obliczanie trendu za pomocą prostej regresji liniowej
        double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
        int n = historicalData.size();

        for (int i = 0; i < n; i++) {
            double x = i; // indeks jako zmienna x (czas)
            double y = historicalData[i].toMap()["value"].toDouble();

            sumX += x;
            sumY += y;
            sumXY += x * y;
            sumX2 += x * x;
        }

        // Wzór na współczynnik kierunkowy linii trendu (slope)
        trendSlope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);

        // Określenie kierunku trendu
        if (trendSlope > 0.01) {
            trendDirection = "wzrostowy";
        } else if (trendSlope < -0.01) {
            trendDirection = "malejący";
        }
    }

    // Update stats map
    QVariantMap parameterStats;
    parameterStats["min"] = min;
    parameterStats["max"] = max;
    parameterStats["avg"] = average;
    parameterStats["count"] = historicalData.size();
    parameterStats["startDate"] = firstDate.toString(Qt::ISODate);
    parameterStats["endDate"] = lastDate.toString(Qt::ISODate);
    parameterStats["paramCode"] = historicalData.first().toMap()["paramCode"];

    // Informacje o trendzie
    parameterStats["trendSlope"] = trendSlope;
    parameterStats["trendDirection"] = trendDirection;

    emit statsCalculated(parameterStats);
}

void WorkerThread::saveDataToFile(const QString &filePath, const QVariantMap &dataToSave) {
    QFile file(filePath);
    if (file.open(QIODevice::WriteOnly)) {
        QJsonDocument doc = QJsonDocument::fromVariant(dataToSave);
        file.write(doc.toJson());
        file.close();
        emit dataSaved(true, "Dane zostały zapisane");
    } else {
        emit dataSaved(false, "Błąd przy zapisywaniu danych: " + file.errorString());
    }
}

void WorkerThread::loadDataFromFile(const QString &filePath) {
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        emit dataLoaded(QVariantMap(), false, "Błąd przy wczytywaniu danych: " + file.errorString());
        return;
    }

    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    file.close();

    if (!doc.isObject()) {
        emit dataLoaded(QVariantMap(), false, "Nieprawidłowy format pliku");
        return;
    }

    QVariantMap loadedData = doc.toVariant().toMap();
    emit dataLoaded(loadedData, true, "Dane wczytane poprawnie");
}

void WorkerThread::checkNetworkConnection() {
    QUrl testUrl("https://api.gios.gov.pl/pjp-api/rest/station/findAll");
    QNetworkRequest request(testUrl);

    QNetworkReply *testReply = m_networkManager->head(request); // Używamy HEAD dla minimalnej transmisji danych

    connect(testReply, &QNetworkReply::finished, this, [this, testReply]() {
        bool isOnline = (testReply->error() == QNetworkReply::NoError);

        // Aktualizujemy status sieci tylko jeśli się zmienił
        if (m_isNetworkAvailable != isOnline) {
            m_isNetworkAvailable = isOnline;
            emit networkStatusChanged(isOnline);
        }

        testReply->deleteLater();
    });
}
