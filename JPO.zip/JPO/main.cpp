#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QStandardPaths>
#include "mainwindow.h"
#include "threadmanager.h"

int main(int argc, char *argv[]) {
    // Ustawienie atrybutu dla aplikacji Qt
    QGuiApplication::setHighDpiScaleFactorRoundingPolicy(Qt::HighDpiScaleFactorRoundingPolicy::PassThrough);
    QGuiApplication app(argc, argv);

    // Ustawienie nazwy organizacji i aplikacji dla QSettings
    app.setOrganizationName("YourOrganization");
    app.setApplicationName("AirQualityApp");
    app.setApplicationVersion("1.0.0");

    // Ustawienie obsługi błędów
    qInstallMessageHandler([](QtMsgType type, const QMessageLogContext &context, const QString &msg) {
        if (type == QtFatalMsg) {
            fprintf(stderr, "Fatal Error: %s\n", qPrintable(msg));
            // Log to file
            QFile logFile(QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/crash.log");
            if (logFile.open(QIODevice::WriteOnly | QIODevice::Append)) {
                QTextStream stream(&logFile);
                stream << QDateTime::currentDateTime().toString() << " - Fatal: " << msg << "\n";
                logFile.close();
            }
        }

        // Forward to default handler
        fprintf(stderr, "[%s:%d] %s\n", context.file ? context.file : "unknown",
                context.line, qPrintable(msg));
    });

    // Rejestracja typów dla QML
    qRegisterMetaType<QVariantList>("QVariantList");
    qRegisterMetaType<QVariantMap>("QVariantMap");

    ThreadManager *threadManager = nullptr;
    MainWindow *mainWindow = nullptr;

    try {
        qDebug() << "Creating ThreadManager";
        threadManager = new ThreadManager(&app);

        qDebug() << "Starting threads";
        threadManager->startThread(ThreadManager::NetworkMonitor);
        threadManager->startThread(ThreadManager::FileOperations);
        threadManager->startThread(ThreadManager::DataProcessor);
        threadManager->startThread(ThreadManager::NetworkWorker);

        qDebug() << "All threads started successfully";

        qDebug() << "Creating MainWindow";
        mainWindow = new MainWindow(threadManager);
    }
    catch (const std::exception& e) {
        qFatal("Exception in main: %s", e.what());
        return 1;
    }
    catch (...) {
        qFatal("Unknown exception in main");
        return 1;
    }

    QQmlApplicationEngine engine;

    // Ustawienie kontekstu QML
    if (mainWindow && threadManager) {
        engine.rootContext()->setContextProperty("mainWindow", mainWindow);
        engine.rootContext()->setContextProperty("threadManager", threadManager);
    } else {
        qFatal("Failed to create mainWindow or threadManager");
        return 1;
    }

    // Załadowanie głównego pliku QML
    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
                         if (!obj && url == objUrl) {
                             qDebug() << "Failed to create QML object";
                             QCoreApplication::exit(-1);
                         } else if (obj && url == objUrl) {
                             qDebug() << "QML object created successfully";
                         }
                     }, Qt::QueuedConnection);

    engine.load(url);

    // Połączenie dla czyszczenia
    QObject::connect(&app, &QCoreApplication::aboutToQuit, [threadManager]() {
        qDebug() << "Application shutting down";
        if (threadManager) {
            threadManager->stopAllThreads();
        }
    });

    return app.exec();
}
