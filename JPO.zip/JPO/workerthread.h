// Implementacja WorkerThread - nowa klasa do obsługi operacji sieciowych
#ifndef WORKERTHREAD_H
#define WORKERTHREAD_H

#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMutex>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QObject>
#include <QThread>
#include <QVariantList>
#include <QVariantMap>
#include <QTimer>

class WorkerThread : public QObject
{
    Q_OBJECT

public:
    explicit WorkerThread(QObject *parent = nullptr);
    ~WorkerThread();

public slots:
    // Sloty do wołania z głównego wątku
    void fetchStations(const QString &city);
    void fetchSensorData(int stationId);
    void fetchAirQualityIndex(int stationId);
    void fetchHistoricalData(int sensorId, const QString &paramCode);
    void saveDataToFile(const QString &filePath, const QVariantMap &dataToSave);
    void loadDataFromFile(const QString &filePath);
    void calculateStats(const QVariantList &historicalData);
    void initialize();
    void setup();

signals:
    // Sygnały emitowane do głównego wątku
    void stationsReady(const QVariantList &stations, const QString &city);
    void stationsError(const QString &errorMessage);
    void sensorDataReady(const QVariantList &sensorData);
    void sensorDataError(const QString &errorMessage);
    void airQualityIndexReady(const QVariantMap &airQualityIndex);
    void airQualityIndexError(const QString &errorMessage);
    void historicalDataReady(const QVariantList &historicalData);
    void historicalDataError(const QString &errorMessage);
    void statsCalculated(const QVariantMap &stats);
    void dataSaved(bool success, const QString &message);
    void dataLoaded(const QVariantMap &loadedData, bool success, const QString &message);
    void networkError(const QString &errorMessage);
    void networkStatusChanged(bool isAvailable);

private slots:
    void onNetworkReply(QNetworkReply *reply);
    void onSensorDataReply(QNetworkReply *reply);
    void onMeasurementDataReply(QNetworkReply *reply,
                                int sensorId,
                                const QString &paramName,
                                const QString &paramFormula,
                                const QString &paramCode);
    void onAirQualityIndexReply(QNetworkReply *reply);
    void onHistoricalDataReply(QNetworkReply *reply, int sensorId, const QString &paramCode);
    void checkNetworkConnection();

private:
    QNetworkAccessManager *m_networkManager;
    QMutex m_mutex;
    QString m_currentCity;
    int m_pendingSensors;
    QVariantList m_sensorData;
    QVariantList m_historicalData;
    bool m_isNetworkAvailable;
    QTimer *m_networkCheckTimer;

    void processStationsResponse(const QByteArray &responseData);
};

#endif // WORKERTHREAD_H
