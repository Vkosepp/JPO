#include "fileoperationsthread.h"
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QDateTime>
#include <QDebug>
#include <QTextStream>
#include <QCryptographicHash>
#include <QStringConverter>
#include <QRegularExpression>
#include <QTimer>
#include <QStandardPaths>

FileOperationsThread::FileOperationsThread(QObject *parent)
    : QObject(parent)
{
    // Ustawienie domyślnego katalogu na dane aplikacji
    m_defaultDirectory = QDir::homePath() + QDir::separator() + ".airqualityapp";
    ensureDirectoryExists(m_defaultDirectory);
}

FileOperationsThread::~FileOperationsThread()
{
}

void FileOperationsThread::initialize() {
    qDebug() << "FileOperationsThread initialized in thread:" << QThread::currentThreadId();

    // Upewnij się, że katalog na zapisane dane istnieje
    m_defaultDirectory = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/savedData";
    ensureDirectoryExists(m_defaultDirectory);
}

void FileOperationsThread::saveDataToFile(const QString &filePath, const QVariantMap &dataToSave)
{
    QMutexLocker locker(&m_mutex);

    try {
        QString actualFilePath = filePath;

        // Jeśli ścieżka nie została podana, użyj domyślnej ścieżki z timestampem
        if (actualFilePath.isEmpty()) {
            QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd_HH-mm-ss");
            actualFilePath = m_defaultDirectory + QDir::separator() + "data_" + timestamp + ".json";
        }

        // Sprawdź czy katalog istnieje, jeśli nie, utwórz go
        QFileInfo fileInfo(actualFilePath);
        QDir dir = fileInfo.dir();
        if (!dir.exists()) {
            if (!dir.mkpath(".")) {
                emit dataSaved(false, "Nie można utworzyć katalogu: " + dir.path(), QString());
                return;
            }
        }

        // Konwersja danych do formatu JSON
        QJsonObject jsonObject = QJsonObject::fromVariantMap(dataToSave);
        QJsonDocument jsonDoc(jsonObject);
        QByteArray jsonData = jsonDoc.toJson(QJsonDocument::Indented);

        // Zapis do pliku
        QFile file(actualFilePath);
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            emit dataSaved(false, "Nie można otworzyć pliku do zapisu: " + file.errorString(), QString());
            return;
        }


        file.write(jsonData);
        file.close();

        // Dodanie metadanych do nazwy pliku
        if (dataToSave.contains("city") || dataToSave.contains("stationName")) {
            QString city = dataToSave["city"].toString();
            QString stationName = dataToSave["stationName"].toString();
            QString newFileName = fileInfo.path() + QDir::separator();

            if (!city.isEmpty()) newFileName += city + "_";
            if (!stationName.isEmpty()) newFileName += stationName + "_";

            newFileName += fileInfo.fileName();

            // Jeśli nazwa się zmieniła, zmień nazwę pliku
            if (newFileName != actualFilePath) {
                QFile::rename(actualFilePath, newFileName);
                actualFilePath = newFileName;
            }
        }

        emit dataSaved(true, "Dane zapisane pomyślnie do pliku", actualFilePath);
    }
    catch (const std::exception &e) {
        emit fileError(QString("Błąd podczas zapisywania danych: %1").arg(e.what()));
    }
}

void FileOperationsThread::loadDataFromFile(const QString &filePath)
{
    QMutexLocker locker(&m_mutex);

    try {
        // Sprawdzenie, czy plik istnieje
        QFile file(filePath);
        if (!file.exists()) {
            emit dataLoaded(QVariantMap(), false, "Plik nie istnieje: " + filePath);
            return;
        }

        // Otwarcie pliku
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            emit dataLoaded(QVariantMap(), false, "Nie można otworzyć pliku do odczytu: " + file.errorString());
            return;
        }

        // Odczyt danych JSON
        QByteArray jsonData = file.readAll();
        file.close();

        QJsonParseError parseError;
        QJsonDocument jsonDoc = QJsonDocument::fromJson(jsonData, &parseError);

        if (parseError.error != QJsonParseError::NoError) {
            emit dataLoaded(QVariantMap(), false, "Błąd parsowania JSON: " + parseError.errorString());
            return;
        }

        if (!jsonDoc.isObject()) {
            emit dataLoaded(QVariantMap(), false, "Nieprawidłowy format JSON: oczekiwano obiektu");
            return;
        }

        QVariantMap loadedData = jsonDoc.object().toVariantMap();

        // Dodanie informacji o pliku
        QFileInfo fileInfo(file);
        loadedData["filePath"] = filePath;
        loadedData["fileName"] = fileInfo.fileName();
        loadedData["lastModified"] = fileInfo.lastModified().toString(Qt::ISODate);

        emit dataLoaded(loadedData, true, "Dane wczytane pomyślnie");
    }
    catch (const std::exception &e) {
        emit fileError(QString("Błąd podczas wczytywania danych: %1").arg(e.what()));
    }
}

void FileOperationsThread::listSavedFiles(const QString &directory)
{
    QMutexLocker locker(&m_mutex);

    try {
        QString dirPath = directory.isEmpty() ? m_defaultDirectory : directory;
        QDir dir(dirPath);

        if (!dir.exists()) {
            emit fileListReady(QVariantList());
            return;
        }

        // Filtrowanie plików JSON
        QStringList filters;
        filters << "*.json";
        dir.setNameFilters(filters);
        dir.setSorting(QDir::Time); // Sortowanie wg czasu modyfikacji (od najnowszych)

        QFileInfoList fileList = dir.entryInfoList();
        QVariantList fileDataList;

        for (const QFileInfo &fileInfo : fileList) {
            QVariantMap fileData;
            fileData["filePath"] = fileInfo.absoluteFilePath();
            fileData["fileName"] = fileInfo.fileName();
            fileData["lastModified"] = fileInfo.lastModified().toString("yyyy-MM-dd HH:mm:ss");
            fileData["size"] = fileInfo.size();

            // Próba odczytania podstawowych informacji z pliku
            QFile file(fileInfo.absoluteFilePath());
            if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
                QByteArray jsonData = file.readAll();
                file.close();

                QJsonDocument jsonDoc = QJsonDocument::fromJson(jsonData);
                if (jsonDoc.isObject()) {
                    QJsonObject jsonObj = jsonDoc.object();

                    // Dodanie podstawowych informacji z pliku
                    if (jsonObj.contains("city"))
                        fileData["city"] = jsonObj["city"].toString();

                    if (jsonObj.contains("stationName"))
                        fileData["stationName"] = jsonObj["stationName"].toString();

                    if (jsonObj.contains("measurementDate"))
                        fileData["measurementDate"] = jsonObj["measurementDate"].toString();
                }
            }

            fileDataList.append(fileData);
        }

        emit fileListReady(fileDataList);
    }
    catch (const std::exception &e) {
        emit fileError(QString("Błąd podczas listowania plików: %1").arg(e.what()));
    }
}

void FileOperationsThread::deleteFile(const QString &filePath)
{
    QMutexLocker locker(&m_mutex);

    try {
        QFile file(filePath);

        if (!file.exists()) {
            emit fileDeleted(false, "Plik nie istnieje: " + filePath);
            return;
        }

        if (file.remove()) {
            emit fileDeleted(true, "Plik usunięty pomyślnie: " + filePath);
        } else {
            emit fileDeleted(false, "Nie można usunąć pliku: " + file.errorString());
        }
    }
    catch (const std::exception &e) {
        emit fileError(QString("Błąd podczas usuwania pliku: %1").arg(e.what()));
    }
}

void FileOperationsThread::createBackup(const QVariantMap &dataToBackup)
{
    QMutexLocker locker(&m_mutex);

    try {
        // Utworzenie katalogu backupu
        QString backupDir = m_defaultDirectory + QDir::separator() + "backups";
        ensureDirectoryExists(backupDir);

        // Generowanie nazwy pliku backupu
        QString backupFileName = generateBackupFileName();
        QString backupFilePath = backupDir + QDir::separator() + backupFileName;

        // Zapisanie danych do pliku backupu
        QJsonObject jsonObject = QJsonObject::fromVariantMap(dataToBackup);
        QJsonDocument jsonDoc(jsonObject);
        QByteArray jsonData = jsonDoc.toJson(QJsonDocument::Indented);

        QFile file(backupFilePath);
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            emit backupCreated(false, QString());
            return;
        }

        file.write(jsonData);
        file.close();

        emit backupCreated(true, backupFilePath);
    }
    catch (const std::exception &e) {
        emit fileError(QString("Błąd podczas tworzenia kopii zapasowej: %1").arg(e.what()));
    }
}

void FileOperationsThread::checkFileExists(const QString &filePath)
{
    QMutexLocker locker(&m_mutex);

    try {
        bool exists = QFile::exists(filePath);
        emit fileExistsResult(exists, filePath);
    }
    catch (const std::exception &e) {
        emit fileError(QString("Błąd podczas sprawdzania istnienia pliku: %1").arg(e.what()));
    }
}

void FileOperationsThread::exportToCsv(const QString &filePath, const QVariantList &dataToExport, const QStringList &headers)
{
    QMutexLocker locker(&m_mutex);

    try {
        if (dataToExport.isEmpty()) {
            emit dataExported(false, "Brak danych do eksportu", QString());
            return;
        }

        // Ustawienie domyślnej ścieżki, jeśli nie podano
        QString actualFilePath = filePath;
        if (actualFilePath.isEmpty()) {
            QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd_HH-mm-ss");
            actualFilePath = m_defaultDirectory + QDir::separator() + "export_" + timestamp + ".csv";
        }

        // Sprawdzenie czy katalog istnieje
        QFileInfo fileInfo(actualFilePath);
        QDir dir = fileInfo.dir();
        if (!dir.exists()) {
            if (!dir.mkpath(".")) {
                emit dataExported(false, "Nie można utworzyć katalogu: " + dir.path(), QString());
                return;
            }
        }

        // Otwarcie pliku do zapisu
        QFile file(actualFilePath);
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            emit dataExported(false, "Nie można otworzyć pliku do zapisu: " + file.errorString(), QString());
            return;
        }

        QTextStream out(&file);
        out.setEncoding(QStringConverter::Encoding::Utf8);

        // Zapisanie nagłówków
        if (!headers.isEmpty()) {
            out << headers.join(";") << "\n";
        } else {
            // Jeśli nie podano nagłówków, użyj kluczy z pierwszego obiektu
            if (!dataToExport.isEmpty() && dataToExport.first().canConvert<QVariantMap>()) {
                QVariantMap firstItem = dataToExport.first().toMap();
                QStringList keys = firstItem.keys();
                out << keys.join(";") << "\n";
            }
        }

        // Zapisanie danych
        for (const QVariant &item : dataToExport) {
            if (item.canConvert<QVariantMap>()) {
                QVariantMap dataMap = item.toMap();
                QStringList values;

                // Jeśli podano nagłówki, użyj ich jako klucze
                if (!headers.isEmpty()) {
                    for (const QString &header : headers) {
                        values << dataMap.value(header).toString();
                    }
                } else {
                    // W przeciwnym razie użyj wszystkich kluczy z pierwszego obiektu
                    QVariantMap firstItem = dataToExport.first().toMap();
                    for (const QString &key : firstItem.keys()) {
                        values << dataMap.value(key).toString();
                    }
                }

                out << values.join(";") << "\n";
            }
        }

        file.close();
        emit dataExported(true, "Dane wyeksportowane pomyślnie", actualFilePath);
    }
    catch (const std::exception &e) {
        emit fileError(QString("Błąd podczas eksportu danych: %1").arg(e.what()));
    }
}

QString FileOperationsThread::ensureDirectoryExists(const QString &dirPath)
{
    QDir dir(dirPath);
    if (!dir.exists()) {
        if (!dir.mkpath(".")) {
            qWarning() << "Nie można utworzyć katalogu:" << dirPath;
            return QString();
        }
    }
    return dirPath;
}

QString FileOperationsThread::generateBackupFileName() const
{
    // Generowanie nazwy pliku backupu bazującego na czasie
    QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd_HH-mm-ss");

    // Dodanie losowego hasha dla unikalności
    QByteArray hashData = QCryptographicHash::hash(
                              QByteArray::number(QDateTime::currentMSecsSinceEpoch()),
                              QCryptographicHash::Md5
                              ).toHex();

    return QString("backup_%1_%2.json").arg(timestamp).arg(QString(hashData).left(8));
}

QString FileOperationsThread::sanitizeFileName(const QString &fileName) const
{
    // Usunięcie niedozwolonych znaków w nazwach plików
    QString sanitized = fileName;
    sanitized.replace(QRegularExpression("[\\\\/:*?\"<>|]"), "_");
    return sanitized;
}

bool FileOperationsThread::isValidFilePath(const QString &filePath) const
{
    QFileInfo fileInfo(filePath);

    // Sprawdzenie, czy katalog istnieje i czy mamy uprawnienia do zapisu
    return fileInfo.exists() && fileInfo.isFile() && fileInfo.isReadable();
}
