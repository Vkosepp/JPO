#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QObject>
#include <QVariant>

// Forward declaration
class ThreadManager;

class MainWindow : public QObject {
    Q_OBJECT
    // Właściwość do przechowywania listy stacji
    Q_PROPERTY(QVariantList stations READ stations NOTIFY stationsChanged)
    // Właściwość do przechowywania statusu
    Q_PROPERTY(QString status READ status NOTIFY statusChanged)
    // Właściwość do przechowywania aktualnie wybranego miasta
    Q_PROPERTY(QString currentCity READ currentCity WRITE setCurrentCity NOTIFY currentCityChanged)
    // Właściwości dla danych sensorów stacji
    Q_PROPERTY(QVariantList sensorData READ sensorData NOTIFY sensorDataChanged)
    Q_PROPERTY(QString dataStatus READ dataStatus NOTIFY dataStatusChanged)
    // Właściwość do przechowywania indeksu jakości powietrza
    Q_PROPERTY(QVariantMap airQualityIndex READ airQualityIndex NOTIFY airQualityIndexChanged)
    Q_PROPERTY(QVariantList historicalData READ historicalData NOTIFY historicalDataChanged)
    Q_PROPERTY(QVariantMap parameterStats READ parameterStats NOTIFY parameterStatsChanged)
    Q_PROPERTY(QString graphStatus READ graphStatus NOTIFY graphStatusChanged)
    // Właściwość dla trybu offline
    Q_PROPERTY(bool offlineMode READ offlineMode NOTIFY offlineModeChanged)
    // Właściwości dla zapisanych danych
    Q_PROPERTY(QVariantList savedDataList READ savedDataList NOTIFY savedDataListChanged)
    Q_PROPERTY(QString savedDataStatus READ savedDataStatus NOTIFY savedDataStatusChanged)
    Q_PROPERTY(int currentStationIndex READ currentStationIndex WRITE setCurrentStationIndex NOTIFY currentStationIndexChanged)

public:
    explicit MainWindow(ThreadManager* threadManager, QObject *parent = nullptr);
    ~MainWindow();

    // Gettery dla właściwości
    QVariantList stations() const { return m_stations; }
    QString status() const { return m_status; }
    QString currentCity() const { return m_currentCity; }
    QVariantList sensorData() const { return m_sensorData; }
    QString dataStatus() const { return m_dataStatus; }
    QVariantMap airQualityIndex() const { return m_airQualityIndex; }
    QVariantList historicalData() const { return m_historicalData; }
    QVariantMap parameterStats() const { return m_parameterStats; }
    QString graphStatus() const { return m_graphStatus; }
    QVariantList savedDataList() const { return m_savedDataList; }
    QString savedDataStatus() const { return m_savedDataStatus; }
    int currentStationIndex() const { return m_currentStationIndex; }
    bool offlineMode() const { return m_offlineMode; }

    // Settery dla właściwości
    void setCurrentCity(const QString &city);
    void setCurrentStationIndex(int index);

    // Metody wywoływane z QML
    Q_INVOKABLE void saveCurrentData();
    Q_INVOKABLE void loadSavedDataList();
    Q_INVOKABLE void loadSavedData(const QString &filePath);
    Q_INVOKABLE void deleteSavedData(const QString &filePath);
    Q_INVOKABLE void exitOfflineMode();

public slots:
    // Funkcja do pobierania danych z API
    void fetchStations();
    // Funkcja do pobierania danych o sensorach i pomiarach
    void fetchSensorData(int stationId);
    // Funkcja do pobierania indeksu jakości powietrza
    void fetchAirQualityIndex(int stationId);
    // Funkcja do pobierania danych historycznych
    void fetchHistoricalData(int sensorId, const QString &paramCode);
    // Funkcja do obliczania statystyk
    void calculateStats();

signals:
    // Sygnały informujące o zmianie danych
    void stationsChanged();
    void statusChanged();
    void currentCityChanged();
    void sensorDataChanged();
    void dataStatusChanged();
    void airQualityIndexChanged();
    void historicalDataChanged();
    void parameterStatsChanged();
    void graphStatusChanged();
    void savedDataListChanged();
    void savedDataStatusChanged();
    void currentStationIndexChanged();
    void offlineModeChanged();

private:
    ThreadManager* m_threadManager; // Reference to the thread manager
    QVariantList m_stations;       // Lista stacji
    QString m_status;              // Status ładowania
    QString m_currentCity;         // Aktualnie wybrane miasto
    QVariantList m_sensorData;     // Dane sensorów
    QString m_dataStatus;          // Status ładowania danych sensorów
    QVariantMap m_airQualityIndex; // Indeks jakości powietrza
    QVariantList m_historicalData; // Dane historyczne
    QVariantMap m_parameterStats;  // Statystyki parametrów
    QString m_graphStatus;         // Status wykresu
    QVariantList m_savedDataList;  // Lista zapisanych danych
    QString m_savedDataStatus;     // Status zapisanych danych
    int m_currentStationIndex;     // Indeks aktualnie wybranej stacji
    bool m_offlineMode;            // Tryb offline
    bool m_isNetworkAvailable;     // Dostępność sieci

    // Metody prywatne
    void checkNetworkConnection();
    void updateOfflineMode();
    void loadMostRecentDataForCity(const QString &city);
};
#endif // MAINWINDOW_H
