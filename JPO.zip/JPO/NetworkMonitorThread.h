#ifndef NETWORKMONITORTHREAD_H
#define NETWORKMONITORTHREAD_H

#include <QObject>
#include <QTimer>
#include <QMutex>
#include <QQueue>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QHostInfo>
#include <QDateTime>
#include <QPair>
#include <QVariantMap>

class NetworkMonitorThread : public QObject
{
    Q_OBJECT

public:
    explicit NetworkMonitorThread(QObject *parent = nullptr);
    ~NetworkMonitorThread();

    // Make these methods available for invocation from other threads
    Q_INVOKABLE void initialize();
    Q_INVOKABLE void stopMonitoring();
    Q_INVOKABLE void startMonitoring(int intervalMs = 10000);
    Q_INVOKABLE void checkConnection();
    Q_INVOKABLE void checkSpecificEndpoint(const QString &endpoint);
    Q_INVOKABLE void testConnectionSpeed();
    Q_INVOKABLE void queueTaskWhenOnline(const QString &taskType, const QVariantMap &taskData);

signals:
    void networkStatusChanged(bool isAvailable);
    void networkError(const QString &errorMessage);
    void specificEndpointStatus(const QString &endpoint, bool isAvailable, int responseTime);
    void connectionSpeedMeasured(double speedKbps);
    void networkStats(const QVariantMap &stats);
    void executeQueuedTask(const QString &taskType, const QVariantMap &taskData);
    void taskExecuted(const QString &taskType, const QVariantMap &taskData, bool success);

private slots:
    void onNetworkRequestFinished(QNetworkReply *reply);
    void onLookupFinished(const QHostInfo &hostInfo);
    void onSpeedTestFinished();
    void onCheckTimerTimeout();
    void processPendingTasks();

private:
    void updateNetworkStats(bool isSuccess, int responseTimeMs);
    void executeTask(const QString &taskType, const QVariantMap &taskData);

    bool m_isNetworkAvailable;
    int m_consecutiveFailures;
    int m_checkInterval;
    QDateTime m_lastSuccessfulCheck;
    QDateTime m_speedTestStartTime;

    QNetworkAccessManager *m_networkManager;
    QTimer *m_checkTimer;
    QTimer *m_taskProcessingTimer;
    QMutex m_mutex;

    QString m_testEndpoint = "https://api.gios.gov.pl/pjp-api/rest/station/findAll";
    QQueue<QPair<QString, QVariantMap>> m_pendingTasks;
    QVariantMap m_networkStats;
};

#endif // NETWORKMONITORTHREAD_H
