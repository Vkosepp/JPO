#include "threadmanager.h"
#include <QDebug>

ThreadManager::ThreadManager(QObject *parent) : QObject(parent)
{
    // Inicjalizacja wątków i obiektów do nich przypisanych
    m_networkWorkerThread = new QThread(this);
    m_dataProcessingThread = new QThread(this);
    m_fileOperationsThread = new QThread(this);
    m_networkMonitorThread = new QThread(this);

    // Tworzenie obiektów
    m_networkWorker = new WorkerThread();
    m_dataProcessor = new DataProcessingThread();
    m_fileOperations = new FileOperationsThread();
    m_networkMonitor = new NetworkMonitorThread();

    // Przypisanie do wątków
    m_networkWorker->moveToThread(m_networkWorkerThread);
    m_dataProcessor->moveToThread(m_dataProcessingThread);
    m_fileOperations->moveToThread(m_fileOperationsThread);
    m_networkMonitor->moveToThread(m_networkMonitorThread);

    // Inicjalizacja stanu wątków
    m_threadRunningStatus[NetworkWorker] = false;
    m_threadRunningStatus[DataProcessor] = false;
    m_threadRunningStatus[FileOperations] = false;
    m_threadRunningStatus[NetworkMonitor] = false;

    // Połączenia dla metod initialize
    connect(m_networkWorkerThread, &QThread::started, m_networkWorker, &WorkerThread::initialize);
    connect(m_dataProcessingThread, &QThread::started, m_dataProcessor, &DataProcessingThread::initialize);
    connect(m_fileOperationsThread, &QThread::started, m_fileOperations, &FileOperationsThread::initialize);
    connect(m_networkMonitorThread, &QThread::started, m_networkMonitor, &NetworkMonitorThread::initialize);
}

ThreadManager::~ThreadManager()
{
    qDebug() << "ThreadManager destructor called";

    // Stop all threads first
    stopAllThreads();

    // Extra safety: wait a bit to ensure everything is stopped
    QThread::msleep(200);
}

void ThreadManager::startThread(ThreadType threadType)
{
    qDebug() << "Starting thread:" << threadType;

    QMutexLocker locker(&m_mutex);

    // Don't start a thread that's already running
    if (m_threadRunningStatus.value(threadType, false)) {
        qDebug() << "Thread already running:" << threadType;
        return;
    }

    try {
        switch (threadType) {
        case NetworkWorker:
            qDebug() << "Creating NetworkWorker thread";
            m_networkWorkerThread = new QThread();
            m_networkWorker = new WorkerThread();

            // Move to thread before making connections
            m_networkWorker->moveToThread(m_networkWorkerThread);

            // Connect thread finished signals for cleanup
            connect(m_networkWorkerThread, &QThread::finished,
                    m_networkWorker, &QObject::deleteLater);
            connect(m_networkWorkerThread, &QThread::finished,
                    m_networkWorkerThread, &QObject::deleteLater);

            // Start the thread
            m_networkWorkerThread->start();

            // Connect worker signals
            connect(m_networkWorker, &WorkerThread::networkError,
                    this, [this](const QString &error) {
                        emit threadError(NetworkWorker, error);
                    }, Qt::QueuedConnection);

            connect(m_networkWorker, &WorkerThread::stationsReady,
                    this, &ThreadManager::stationsReady, Qt::QueuedConnection);
            connect(m_networkWorker, &WorkerThread::sensorDataReady,
                    this, &ThreadManager::sensorDataReady, Qt::QueuedConnection);
            connect(m_networkWorker, &WorkerThread::airQualityIndexReady,
                    this, &ThreadManager::airQualityIndexReady, Qt::QueuedConnection);
            connect(m_networkWorker, &WorkerThread::historicalDataReady,
                    this, &ThreadManager::historicalDataReady, Qt::QueuedConnection);
            connect(m_networkWorker, &WorkerThread::statsCalculated,
                    this, &ThreadManager::statsCalculated, Qt::QueuedConnection);
            connect(m_networkWorker, &WorkerThread::networkStatusChanged,
                    this, &ThreadManager::networkStatusChanged, Qt::QueuedConnection);

            // Initialize worker in its thread
            QMetaObject::invokeMethod(m_networkWorker, "initialize", Qt::QueuedConnection);

            m_threadRunningStatus[NetworkWorker] = true;
            qDebug() << "NetworkWorker thread started successfully";
            emit threadStarted(NetworkWorker);
            break;

        case DataProcessor:
            qDebug() << "Creating DataProcessor thread";
            m_dataProcessingThread = new QThread();
            m_dataProcessor = new DataProcessingThread();

            m_dataProcessor->moveToThread(m_dataProcessingThread);

            connect(m_dataProcessingThread, &QThread::finished,
                    m_dataProcessor, &QObject::deleteLater);
            connect(m_dataProcessingThread, &QThread::finished,
                    m_dataProcessingThread, &QObject::deleteLater);

            m_dataProcessingThread->start();

            connect(m_dataProcessor, &DataProcessingThread::processingError,
                    this, [this](const QString &error) {
                        emit threadError(DataProcessor, error);
                    }, Qt::QueuedConnection);

            connect(m_dataProcessor, &DataProcessingThread::statsCalculated,
                    this, &ThreadManager::statsCalculated, Qt::QueuedConnection);
            connect(m_dataProcessor, &DataProcessingThread::sensorDataProcessed,
                    this, &ThreadManager::sensorDataProcessed, Qt::QueuedConnection);
            connect(m_dataProcessor, &DataProcessingThread::airQualityIndexProcessed,
                    this, &ThreadManager::airQualityIndexProcessed, Qt::QueuedConnection);
            connect(m_dataProcessor, &DataProcessingThread::stationsFiltered,
                    this, &ThreadManager::stationsFiltered, Qt::QueuedConnection);

            QMetaObject::invokeMethod(m_dataProcessor, "initialize", Qt::QueuedConnection);

            m_threadRunningStatus[DataProcessor] = true;
            qDebug() << "DataProcessor thread started successfully";
            emit threadStarted(DataProcessor);
            break;

        case FileOperations:
            qDebug() << "Creating FileOperations thread";
            m_fileOperationsThread = new QThread();
            m_fileOperations = new FileOperationsThread();

            m_fileOperations->moveToThread(m_fileOperationsThread);

            connect(m_fileOperationsThread, &QThread::finished,
                    m_fileOperations, &QObject::deleteLater);
            connect(m_fileOperationsThread, &QThread::finished,
                    m_fileOperationsThread, &QObject::deleteLater);

            m_fileOperationsThread->start();

            connect(m_fileOperations, &FileOperationsThread::fileError,
                    this, [this](const QString &error) {
                        emit threadError(FileOperations, error);
                    }, Qt::QueuedConnection);

            connect(m_fileOperations, &FileOperationsThread::dataSaved,
                    this, &ThreadManager::dataSaved, Qt::QueuedConnection);
            connect(m_fileOperations, &FileOperationsThread::dataLoaded,
                    this, &ThreadManager::dataLoaded, Qt::QueuedConnection);
            connect(m_fileOperations, &FileOperationsThread::fileListReady,
                    this, &ThreadManager::fileListReady, Qt::QueuedConnection);
            connect(m_fileOperations, &FileOperationsThread::fileDeleted,
                    this, &ThreadManager::fileDeleted, Qt::QueuedConnection);
            connect(m_fileOperations, &FileOperationsThread::backupCreated,
                    this, &ThreadManager::backupCreated, Qt::QueuedConnection);
            connect(m_fileOperations, &FileOperationsThread::fileExistsResult,
                    this, &ThreadManager::fileExistsResult, Qt::QueuedConnection);
            connect(m_fileOperations, &FileOperationsThread::dataExported,
                    this, &ThreadManager::dataExported, Qt::QueuedConnection);

            QMetaObject::invokeMethod(m_fileOperations, "initialize", Qt::QueuedConnection);

            m_threadRunningStatus[FileOperations] = true;
            qDebug() << "FileOperations thread started successfully";
            emit threadStarted(FileOperations);
            break;

        case NetworkMonitor:
            qDebug() << "Creating NetworkMonitor thread";
            m_networkMonitorThread = new QThread();
            m_networkMonitor = new NetworkMonitorThread();

            m_networkMonitor->moveToThread(m_networkMonitorThread);

            connect(m_networkMonitorThread, &QThread::finished,
                    m_networkMonitor, &QObject::deleteLater);
            connect(m_networkMonitorThread, &QThread::finished,
                    m_networkMonitorThread, &QObject::deleteLater);

            m_networkMonitorThread->start();

            connect(m_networkMonitor, &NetworkMonitorThread::networkError,
                    this, [this](const QString &error) {
                        emit threadError(NetworkMonitor, error);
                    }, Qt::QueuedConnection);

            connect(m_networkMonitor, &NetworkMonitorThread::networkStatusChanged,
                    this, &ThreadManager::networkStatusChanged, Qt::QueuedConnection);

            QMetaObject::invokeMethod(m_networkMonitor, "initialize", Qt::QueuedConnection);

            m_threadRunningStatus[NetworkMonitor] = true;
            qDebug() << "NetworkMonitor thread started successfully";
            emit threadStarted(NetworkMonitor);
            break;
        }
    }
    catch (const std::exception& e) {
        qDebug() << "Exception in startThread:" << e.what();
        emit threadError(threadType, QString("Exception: %1").arg(e.what()));
    }
    catch (...) {
        qDebug() << "Unknown exception in startThread";
        emit threadError(threadType, "Unknown exception occurred");
    }
}

void ThreadManager::stopThread(ThreadType threadType)
{
    qDebug() << "Stopping thread:" << threadType;

    QMutexLocker locker(&m_mutex);

    if (!m_threadRunningStatus.value(threadType, false)) {
        qDebug() << "Thread not running:" << threadType;
        return;
    }

    try {
        switch (threadType) {
        case NetworkWorker:
            if (m_networkWorkerThread) {
                // Disconnect from signals we've connected to
                if (m_networkWorker) {
                    disconnect(m_networkWorker, nullptr, this, nullptr);
                }

                // Request termination
                m_networkWorkerThread->quit();

                // Wait for a reasonable time
                if (!m_networkWorkerThread->wait(3000)) {
                    qDebug() << "NetworkWorker thread timeout - forcing termination";
                    m_networkWorkerThread->terminate();
                    m_networkWorkerThread->wait(1000);
                }

                // Thread and worker will be deleted via deleteLater
                // Just null our pointers
                m_networkWorkerThread = nullptr;
                m_networkWorker = nullptr;
                m_threadRunningStatus[NetworkWorker] = false;
                emit threadStopped(NetworkWorker);
            }
            break;

        case DataProcessor:
            if (m_dataProcessingThread) {
                if (m_dataProcessor) {
                    disconnect(m_dataProcessor, nullptr, this, nullptr);
                }

                m_dataProcessingThread->quit();

                if (!m_dataProcessingThread->wait(3000)) {
                    qDebug() << "DataProcessor thread timeout - forcing termination";
                    m_dataProcessingThread->terminate();
                    m_dataProcessingThread->wait(1000);
                }

                m_dataProcessingThread = nullptr;
                m_dataProcessor = nullptr;
                m_threadRunningStatus[DataProcessor] = false;
                emit threadStopped(DataProcessor);
            }
            break;

        case FileOperations:
            if (m_fileOperationsThread) {
                if (m_fileOperations) {
                    disconnect(m_fileOperations, nullptr, this, nullptr);
                }

                m_fileOperationsThread->quit();

                if (!m_fileOperationsThread->wait(3000)) {
                    qDebug() << "FileOperations thread timeout - forcing termination";
                    m_fileOperationsThread->terminate();
                    m_fileOperationsThread->wait(1000);
                }

                m_fileOperationsThread = nullptr;
                m_fileOperations = nullptr;
                m_threadRunningStatus[FileOperations] = false;
                emit threadStopped(FileOperations);
            }
            break;

        case NetworkMonitor:
            if (m_networkMonitorThread && m_networkMonitor) {
                // First tell the monitor to stop its monitoring activities
                QMetaObject::invokeMethod(m_networkMonitor, "stopMonitoring", Qt::QueuedConnection);

                // Give it a moment to clean up
                QThread::msleep(100);

                disconnect(m_networkMonitor, nullptr, this, nullptr);

                m_networkMonitorThread->quit();

                if (!m_networkMonitorThread->wait(3000)) {
                    qDebug() << "NetworkMonitor thread timeout - forcing termination";
                    m_networkMonitorThread->terminate();
                    m_networkMonitorThread->wait(1000);
                }

                m_networkMonitorThread = nullptr;
                m_networkMonitor = nullptr;
                m_threadRunningStatus[NetworkMonitor] = false;
                emit threadStopped(NetworkMonitor);
            }
            break;
        }
    }
    catch (const std::exception& e) {
        qDebug() << "Exception in stopThread:" << e.what();
    }
    catch (...) {
        qDebug() << "Unknown exception in stopThread";
    }
}

void ThreadManager::stopAllThreads()
{
    qDebug() << "Stopping all threads";

    // Stop in reverse order of dependency to avoid hanging
    stopThread(NetworkWorker);
    stopThread(DataProcessor);
    stopThread(FileOperations);
    stopThread(NetworkMonitor);

    emit allThreadsStopped();
}

WorkerThread* ThreadManager::networkWorker() const
{
    QMutexLocker locker(const_cast<QMutex*>(&m_mutex));
    return m_threadRunningStatus.value(NetworkWorker, false) ? m_networkWorker : nullptr;
}

DataProcessingThread* ThreadManager::dataProcessor() const
{
    QMutexLocker locker(const_cast<QMutex*>(&m_mutex));
    return m_threadRunningStatus.value(DataProcessor, false) ? m_dataProcessor : nullptr;
}

FileOperationsThread* ThreadManager::fileOperations() const
{
    QMutexLocker locker(const_cast<QMutex*>(&m_mutex));
    return m_threadRunningStatus.value(FileOperations, false) ? m_fileOperations : nullptr;
}

NetworkMonitorThread* ThreadManager::networkMonitor() const
{
    QMutexLocker locker(const_cast<QMutex*>(&m_mutex));
    return m_threadRunningStatus.value(NetworkMonitor, false) ? m_networkMonitor : nullptr;
}

bool ThreadManager::isThreadRunning(ThreadType threadType) const
{
    QMutexLocker locker(const_cast<QMutex*>(&m_mutex));
    return m_threadRunningStatus.value(threadType, false);
}

void ThreadManager::safelyConnectThreadSignals(ThreadType /*threadType*/)
{
    // This method is kept for compatibility but no longer used
    // All connections are made directly in startThread() for better safety
}
