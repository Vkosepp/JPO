#include "mainwindow.h"
#include "threadmanager.h"
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QDebug>
#include <QUrlQuery>
#include <QFile>
#include <QDir>
#include <QStandardPaths>
#include <QDateTime>

MainWindow::MainWindow(ThreadManager* threadManager, QObject *parent) : QObject(parent) {
    m_status = "Wpisz nazwę miasta aby znaleźć stacje";
    m_dataStatus = "";
    m_currentCity = "";
    m_offlineMode = false;
    m_isNetworkAvailable = true;
    m_currentStationIndex = 0;
    m_graphStatus = "";
    m_savedDataStatus = "";

    // Store the thread manager reference
    m_threadManager = threadManager;

    // Połączenia sygnałów z WorkerThread
    connect(m_threadManager->networkWorker(), &WorkerThread::stationsReady,
            this, [this](const QVariantList &stations, const QString &city) {
                m_stations = stations;

                if (stations.isEmpty()) {
                    m_status = "Nie znaleziono stacji w " + city + ".";
                } else {
                    m_status = "Znaleziono " + QString::number(stations.size()) + " stacji w " + city + ":";
                }

                emit stationsChanged();
                emit statusChanged();
            });

    connect(m_threadManager->networkWorker(), &WorkerThread::stationsError,
            this, [this](const QString &errorMessage) {
                m_status = "Błąd: " + errorMessage;
                emit statusChanged();
            });

    connect(m_threadManager->networkWorker(), &WorkerThread::sensorDataReady,
            this, [this](const QVariantList &sensorData) {
                m_sensorData = sensorData;
                m_dataStatus = "Dane sensorów załadowane";
                emit sensorDataChanged();
                emit dataStatusChanged();
            });

    connect(m_threadManager->networkWorker(), &WorkerThread::sensorDataError,
            this, [this](const QString &errorMessage) {
                m_dataStatus = "Błąd: " + errorMessage;
                emit dataStatusChanged();
            });

    connect(m_threadManager->networkWorker(), &WorkerThread::airQualityIndexReady,
            this, [this](const QVariantMap &airQualityIndex) {
                m_airQualityIndex = airQualityIndex;
                emit airQualityIndexChanged();
            });

    connect(m_threadManager->networkWorker(), &WorkerThread::airQualityIndexError,
            this, [this](const QString &errorMessage) {
                qDebug() << "Błąd indeksu jakości powietrza: " << errorMessage;
            });

    connect(m_threadManager->networkWorker(), &WorkerThread::historicalDataReady,
            this, [this](const QVariantList &historicalData) {
                m_historicalData = historicalData;
                m_graphStatus = historicalData.isEmpty() ? "Brak danych pomiarowych dla wybranego parametru" : "Dane historyczne załadowane";
                emit historicalDataChanged();
                emit graphStatusChanged();

                if (!historicalData.isEmpty()) {
                    m_threadManager->dataProcessor()->calculateStats(historicalData);
                }
            });

    connect(m_threadManager->networkWorker(), &WorkerThread::historicalDataError,
            this, [this](const QString &errorMessage) {
                m_graphStatus = "Błąd: " + errorMessage;
                emit graphStatusChanged();
            });

    // Połączenia sygnałów z DataProcessingThread
    connect(m_threadManager->dataProcessor(), &DataProcessingThread::statsCalculated,
            this, [this](const QVariantMap &stats) {
                m_parameterStats = stats;
                emit parameterStatsChanged();
            });

    // Połączenia sygnałów z FileOperationsThread
    connect(m_threadManager->fileOperations(), &FileOperationsThread::dataSaved,
            this, [this](bool success, const QString &message, const QString &filePath) {
                if (success) {
                    qDebug() << "Dane zostały zapisane do pliku: " << filePath;
                    loadSavedDataList(); // Odśwież listę zapisanych danych
                } else {
                    qDebug() << "Błąd podczas zapisywania danych: " << message;
                }

                m_savedDataStatus = success ? "Dane zostały zapisane" : "Błąd: " + message;
                emit savedDataStatusChanged();
            },
            Qt::QueuedConnection);


    connect(m_threadManager->fileOperations(), &FileOperationsThread::dataLoaded,
            this, [this](const QVariantMap &loadedData, bool success, const QString &message) {
                if (success) {
                    // Przetwarzanie załadowanych danych
                    if (loadedData.contains("stations")) {
                        m_stations = loadedData["stations"].toList();
                        emit stationsChanged();
                    }

                    if (loadedData.contains("sensorData")) {
                        m_sensorData = loadedData["sensorData"].toList();
                        emit sensorDataChanged();
                    }

                    if (loadedData.contains("airQualityIndex")) {
                        m_airQualityIndex = loadedData["airQualityIndex"].toMap();
                        emit airQualityIndexChanged();
                    }

                    if (loadedData.contains("city")) {
                        m_currentCity = loadedData["city"].toString();
                        emit currentCityChanged();
                    }

                    if (loadedData.contains("historicalData")) {
                        m_historicalData = loadedData["historicalData"].toList();
                        emit historicalDataChanged();
                    }

                    if (loadedData.contains("parameterStats")) {
                        m_parameterStats = loadedData["parameterStats"].toMap();
                        emit parameterStatsChanged();
                    }

                    m_status = "Dane zostały wczytane z pliku";
                    m_dataStatus = "Dane sensorów załadowane";

                    QString saveDate = loadedData["saveDate"].toString();
                    if (!saveDate.isEmpty()) {
                        QDateTime dateTime = QDateTime::fromString(saveDate, Qt::ISODate);
                        m_dataStatus += " z " + dateTime.toString("dd.MM.yyyy HH:mm");
                    }

                    if (m_offlineMode) {
                        m_dataStatus += " (Tryb offline)";
                    }

                    emit statusChanged();
                    emit dataStatusChanged();
                } else {
                    m_savedDataStatus = "Błąd wczytywania danych: " + message;
                    emit savedDataStatusChanged();
                }
            });

    connect(m_threadManager->fileOperations(), &FileOperationsThread::fileListReady,
            this, [this](const QVariantList &fileList) {
                m_savedDataList = fileList;
                m_savedDataStatus = fileList.isEmpty() ? "Brak zapisanych danych" : "Znaleziono " + QString::number(fileList.size()) + " zapisanych plików";
                emit savedDataListChanged();
                emit savedDataStatusChanged();
            });

    connect(m_threadManager->fileOperations(), &FileOperationsThread::fileDeleted,
            this, [this](bool success, const QString &message) {
                if (success) {
                    m_savedDataStatus = "Usunięto zapisane dane";
                    loadSavedDataList(); // Odśwież listę zapisanych danych
                } else {
                    m_savedDataStatus = "Błąd przy usuwaniu pliku: " + message;
                }
                emit savedDataStatusChanged();
            });

    // Połączenia sygnałów z NetworkMonitorThread
    connect(m_threadManager->networkMonitor(), &NetworkMonitorThread::networkStatusChanged,
            this, [this](bool isAvailable) {
                m_isNetworkAvailable = isAvailable;
                updateOfflineMode();
            });

    // Uruchomienie monitorowania sieci
    m_threadManager->networkMonitor()->startMonitoring(10000); // Sprawdzaj co 10 sekund

}

MainWindow::~MainWindow() {
    // No need to stop threads here as ThreadManager is now managed externally
}

void MainWindow::setCurrentCity(const QString &city) {
    if (m_currentCity != city) {
        m_currentCity = city;
        emit currentCityChanged();

        m_status = "Ustawiono miasto: " + city;
        emit statusChanged();

        // Don't fetch stations if we're in offline mode
        if (!city.isEmpty() && !m_offlineMode) {
            fetchStations();
        }
    }
}

void MainWindow::setCurrentStationIndex(int index) {
    if (m_currentStationIndex != index) {
        m_currentStationIndex = index;
        emit currentStationIndexChanged();

        // Jeśli mamy stacje i indeks jest poprawny, pobierz dane dla tej stacji
        if (!m_stations.isEmpty() && index >= 0 && index < m_stations.size()) {
            int stationId = m_stations[index].toMap()["stationId"].toInt();
            fetchSensorData(stationId);
        }
    }
}

void MainWindow::fetchStations() {
    if (m_offlineMode) {
        return;
    }

    m_status = "Pobieranie stacji...";
    emit statusChanged();

    // Delegacja żądania do wątku roboczego
    m_threadManager->networkWorker()->fetchStations(m_currentCity);
}

void MainWindow::fetchSensorData(int stationId) {
    if (m_offlineMode) {
        return;
    }

    // Czyszczenie poprzednich danych
    m_sensorData.clear();
    emit sensorDataChanged();

    m_dataStatus = "Pobieranie danych sensorów...";
    emit dataStatusChanged();

    // Delegacja żądania do wątku roboczego
    m_threadManager->networkWorker()->fetchSensorData(stationId);

    // Pobierz również indeks jakości powietrza dla tej stacji
    fetchAirQualityIndex(stationId);
}

void MainWindow::fetchAirQualityIndex(int stationId) {
    if (m_offlineMode) {
        return;
    }

    // Czyszczenie poprzednich danych
    m_airQualityIndex.clear();
    emit airQualityIndexChanged();

    // Delegacja żądania do wątku roboczego
    m_threadManager->networkWorker()->fetchAirQualityIndex(stationId);
}

void MainWindow::fetchHistoricalData(int sensorId, const QString &paramCode) {
    if (m_offlineMode) {
        return;
    }

    // Clear previous data
    m_historicalData.clear();
    emit historicalDataChanged();

    m_parameterStats.clear();
    emit parameterStatsChanged();

    m_graphStatus = "Pobieranie danych historycznych...";
    emit graphStatusChanged();

    // Delegacja żądania do wątku roboczego
    m_threadManager->networkWorker()->fetchHistoricalData(sensorId, paramCode);
}

void MainWindow::calculateStats() {
    if (m_historicalData.isEmpty()) {
        return;
    }

    // Delegacja obliczania statystyk do wątku przetwarzania danych
    m_threadManager->dataProcessor()->calculateStats(m_historicalData);
}

void MainWindow::saveCurrentData() {
    if (m_stations.isEmpty() || m_currentCity.isEmpty()) {
        m_savedDataStatus = "Brak danych do zapisania";
        emit savedDataStatusChanged();
        return;
    }


    // Przygotowanie danych do zapisania
    QVariantMap dataToSave;
    dataToSave["city"] = m_currentCity;
    dataToSave["stations"] = m_stations;
    dataToSave["sensorData"] = m_sensorData;
    dataToSave["airQualityIndex"] = m_airQualityIndex;
    dataToSave["historicalData"] = m_historicalData;
    dataToSave["parameterStats"] = m_parameterStats;
    dataToSave["saveDate"] = QDateTime::currentDateTime().toString(Qt::ISODate);

    // Generowanie nazwy pliku bazującej na mieście i dacie
    QString fileName = m_currentCity + "_" + QDateTime::currentDateTime().toString("yyyy-MM-dd_HH-mm-ss") + ".json";
    QString dirPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/savedData";
    QString filePath = dirPath + "/" + fileName;

    // Delegacja zapisywania do wątku operacji plikowych
    m_threadManager->fileOperations()->saveDataToFile(filePath, dataToSave);

    m_savedDataStatus = "Zapisywanie danych...";
    emit savedDataStatusChanged();
}

void MainWindow::loadSavedDataList() {
    QString dirPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/savedData";

    // Delegacja listowania plików do wątku operacji plikowych
    m_threadManager->fileOperations()->listSavedFiles(dirPath);

    m_savedDataStatus = "Pobieranie listy zapisanych danych...";
    emit savedDataStatusChanged();
}

void MainWindow::loadSavedData(const QString &filePath) {
    if (filePath.isEmpty()) {
        m_savedDataStatus = "Nieprawidłowa ścieżka pliku";
        emit savedDataStatusChanged();
        return;
    }

    // Delegacja wczytywania do wątku operacji plikowych
    m_threadManager->fileOperations()->loadDataFromFile(filePath);

    m_savedDataStatus = "Wczytywanie danych...";
    emit savedDataStatusChanged();

    // Włącz tryb offline podczas pracy z zapisanymi danymi
    m_offlineMode = true;
    emit offlineModeChanged();
}

void MainWindow::deleteSavedData(const QString &filePath) {
    if (filePath.isEmpty()) {
        m_savedDataStatus = "Nieprawidłowa ścieżka pliku";
        emit savedDataStatusChanged();
        return;
    }

    // Delegacja usuwania do wątku operacji plikowych
    m_threadManager->fileOperations()->deleteFile(filePath);
}

void MainWindow::exitOfflineMode() {
    if (!m_offlineMode) {
        return; // Już jesteśmy w trybie online
    }

    // Sprawdź dostępność sieci przed wyjściem z trybu offline
    m_threadManager->networkMonitor()->checkConnection();

    if (!m_isNetworkAvailable) {
        m_status = "Nie można wyjść z trybu offline - brak połączenia z siecią";
        emit statusChanged();
        return;
    }

    m_offlineMode = false;
    emit offlineModeChanged();

    // Wyczyść dane i zresetuj aplikację
    m_currentCity = "";
    m_stations.clear();
    m_sensorData.clear();
    m_airQualityIndex.clear();
    m_historicalData.clear();
    m_parameterStats.clear();

    m_status = "Wpisz nazwę miasta aby znaleźć stacje";
    m_dataStatus = "";

    // Emit all signals to update UI
    emit currentCityChanged();
    emit stationsChanged();
    emit sensorDataChanged();
    emit airQualityIndexChanged();
    emit historicalDataChanged();
    emit parameterStatsChanged();
    emit statusChanged();
    emit dataStatusChanged();
}

void MainWindow::checkNetworkConnection() {
    // Wykorzystujemy NetworkMonitorThread do sprawdzenia połączenia sieciowego
    m_threadManager->networkMonitor()->checkConnection();
}

void MainWindow::updateOfflineMode() {
    bool shouldBeOffline = !m_isNetworkAvailable;

    if (shouldBeOffline && !m_offlineMode) {
        // Przełączanie na tryb offline
        m_offlineMode = true;
        emit offlineModeChanged();

        m_status = "Tryb offline aktywowany - brak połączenia z internetem";
        emit statusChanged();

        // Próba załadowania ostatnich zapisanych danych dla aktualnego miasta
        if (!m_currentCity.isEmpty()) {
            loadMostRecentDataForCity(m_currentCity);
        }
    } else if (!shouldBeOffline && m_offlineMode) {
        // Użytkownik musi ręcznie wyjść z trybu offline przez exitOfflineMode()
        // Więc tutaj nic nie robimy
    }
}

void MainWindow::loadMostRecentDataForCity(const QString &city) {
    // Najpierw ładujemy listę zapisanych danych
    QString dataDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/savedData";

    // Tworzymy jednorazowe połączenie dla obsługi wyniku listowania plików
    auto connection = new QMetaObject::Connection();
    *connection = connect(m_threadManager->fileOperations(), &FileOperationsThread::fileListReady,
                          [this, city, connection, dataDir](const QVariantList &fileList) {
                              // Rozłączamy sygnał po użyciu
                              QObject::disconnect(*connection);
                              delete connection;

                              // Znajdź najnowsze dane dla wybranego miasta
                              QString mostRecentFilePath;
                              QDateTime mostRecentDate;

                              for (const QVariant &fileInfo : fileList) {
                                  QVariantMap fileMap = fileInfo.toMap();
                                  if (fileMap["city"].toString() == city) {
                                      QDateTime fileDate = QDateTime::fromString(fileMap["saveDate"].toString(), Qt::ISODate);
                                      if (mostRecentFilePath.isEmpty() || fileDate > mostRecentDate) {
                                          mostRecentFilePath = fileMap["filePath"].toString();
                                          mostRecentDate = fileDate;
                                      }
                                  }
                              }

                              // Jeśli znaleźliśmy plik dla danego miasta, załaduj go
                              if (!mostRecentFilePath.isEmpty()) {
                                  loadSavedData(mostRecentFilePath);
                              } else {
                                  m_dataStatus = "Brak zapisanych danych dla miasta " + city;
                                  emit dataStatusChanged();
                              }
                          });

    // Uruchamiamy operację listowania plików
    m_threadManager->fileOperations()->listSavedFiles(dataDir);
}
