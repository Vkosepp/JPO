#ifndef DATAPROCESSINGTHREAD_H
#define DATAPROCESSINGTHREAD_H

#include <QMutex>
#include <QObject>
#include <QThread>
#include <QVariantList>
#include <QVariantMap>

class DataProcessingThread : public QObject
{
    Q_OBJECT

public:
    explicit DataProcessingThread(QObject *parent = nullptr);
    ~DataProcessingThread();

public slots:
    // Obliczanie statystyk dla danych historycznych
    void calculateStats(const QVariantList &historicalData);

    // Przetwarzanie danych sensorów
    void processSensorData(const QVariantList &rawSensorData);

    // Przetwarzanie indeksu jakości powietrza
    void processAirQualityIndex(const QVariantMap &rawAqiData);

    // Filtrowanie stacji według określonych kryteriów
    void filterStations(const QVariantList &stations, const QString &filterCriteria);
    void initialize();

signals:
    // Sygnały emitowane do głównego wątku
    void statsCalculated(const QVariantMap &stats);
    void sensorDataProcessed(const QVariantList &processedData);
    void airQualityIndexProcessed(const QVariantMap &processedAqi);
    void stationsFiltered(const QVariantList &filteredStations);
    void processingError(const QString &errorMessage);

private:
    QMutex m_mutex;

    // Metody pomocnicze do obliczeń
    QVariantMap calculateAverages(const QVariantList &data);
    QVariantMap calculateMinMax(const QVariantList &data);
    double calculateMedian(QList<double> values);
    QVariantMap calculateTrends(const QVariantList &data);
};

#endif // DATAPROCESSINGTHREAD_H
