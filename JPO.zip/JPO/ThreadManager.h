#ifndef THREADMANAGER_H
#define THREADMANAGER_H

#include <QMap>
#include <QMutex>
#include <QObject>
#include <QString>
#include <QThread>
#include "dataprocessingthread.h"
#include "fileoperationsthread.h"
#include "networkmonitorthread.h"
#include "workerthread.h"

class ThreadManager : public QObject
{
    Q_OBJECT

public:
    enum ThreadType { NetworkWorker, DataProcessor, FileOperations, NetworkMonitor };
    Q_ENUM(ThreadType)

    // Changed from singleton to direct instantiation
    explicit ThreadManager(QObject *parent = nullptr);
    ~ThreadManager();

    // Metody do zarządzania wątkami
    void startThread(ThreadType threadType);
    void stopThread(ThreadType threadType);
    void stopAllThreads();

    // Gettery dla obiektów wątków
    WorkerThread *networkWorker() const;
    DataProcessingThread *dataProcessor() const;
    FileOperationsThread *fileOperations() const;
    NetworkMonitorThread *networkMonitor() const;

    // Sprawdzenie, czy wątek jest uruchomiony
    bool isThreadRunning(ThreadType threadType) const;

signals:
    // Sygnały informujące o stanie wątków
    void threadStarted(ThreadType threadType);
    void threadStopped(ThreadType threadType);
    void allThreadsStopped();
    void threadError(ThreadType threadType, const QString &errorMessage);
    void networkStatusChanged(bool isAvailable);

    // Przekazanie sygnałów z DataProcessor
    void statsCalculated(const QVariantMap &stats);
    void sensorDataProcessed(const QVariantList &processedData);
    void airQualityIndexProcessed(const QVariantMap &processedAqi);
    void stationsFiltered(const QVariantList &filteredStations);

    // Przekazanie sygnałów z FileOperations
    void dataSaved(bool success, const QString &message, const QString &filePath);
    void dataLoaded(const QVariantMap &loadedData, bool success, const QString &message);
    void fileListReady(const QVariantList &fileList);
    void fileDeleted(bool success, const QString &message);
    void backupCreated(bool success, const QString &backupPath);
    void fileExistsResult(bool exists, const QString &filePath);
    void dataExported(bool success, const QString &message, const QString &filePath);

    // Przekazanie sygnałów z NetworkWorker
    void stationsReady(const QVariantList &stations, const QString &city);
    void sensorDataReady(const QVariantList &sensorData);
    void airQualityIndexReady(const QVariantMap &airQualityIndex);
    void historicalDataReady(const QVariantList &historicalData);

private:
    // Obiekty wątków
    QThread *m_networkWorkerThread;
    QThread *m_dataProcessingThread;
    QThread *m_fileOperationsThread;
    QThread *m_networkMonitorThread;

    // Obiekty pracujące w wątkach
    WorkerThread *m_networkWorker;
    DataProcessingThread *m_dataProcessor;
    FileOperationsThread *m_fileOperations;
    NetworkMonitorThread *m_networkMonitor;

    // Mapa przechowująca stan wątków
    QMap<ThreadType, bool> m_threadRunningStatus;
    QMutex m_mutex;

    // Metoda pomocnicza
    void safelyConnectThreadSignals(ThreadType threadType);
};

#endif // THREADMANAGER_H
