#include "dataprocessingthread.h"
#include <QDateTime>
#include <QDebug>
#include <algorithm>
#include <Qtimer>

DataProcessingThread::DataProcessingThread(QObject *parent)
    : QObject(parent)
{
}

DataProcessingThread::~DataProcessingThread()
{
}

void DataProcessingThread::initialize() {
     qDebug() << "DataProcessingThread initialized in thread:" << QThread::currentThreadId();
}

void DataProcessingThread::calculateStats(const QVariantList &historicalData)
{
    QMutexLocker locker(&m_mutex);

    try {
        if (historicalData.isEmpty()) {
            emit processingError("Brak danych historycznych do obliczeń");
            return;
        }

        QVariantMap stats;

        // Segregacja danych według parametrów
        QMap<QString, QVariantList> parameterData;
        QMap<QString, QList<double>> parameterValues;

        for (const QVariant &entry : historicalData) {
            QVariantMap dataPoint = entry.toMap();
            QString paramCode = dataPoint["paramCode"].toString();

            if (!parameterData.contains(paramCode)) {
                parameterData[paramCode] = QVariantList();
                parameterValues[paramCode] = QList<double>();
            }

            parameterData[paramCode].append(dataPoint);
            parameterValues[paramCode].append(dataPoint["value"].toDouble());
        }

        // Obliczanie statystyk dla każdego parametru
        for (auto it = parameterData.begin(); it != parameterData.end(); ++it) {
            QString paramCode = it.key();
            QList<double> values = parameterValues[paramCode];

            if (values.isEmpty()) continue;

            // Sortowanie wartości do obliczenia mediany
            std::sort(values.begin(), values.end());

            // Podstawowe statystyki
            double sum = 0;
            for (double value : values) {
                sum += value;
            }

            double avg = sum / values.size();
            double min = values.first();
            double max = values.last();
            double median = calculateMedian(values);

            // Zapisanie statystyk
            QVariantMap paramStats;
            paramStats["average"] = avg;
            paramStats["min"] = min;
            paramStats["max"] = max;
            paramStats["median"] = median;
            paramStats["count"] = values.size();

            // Dodanie trendu, jeśli mamy więcej niż 1 pomiar
            if (values.size() > 1) {
                paramStats["trend"] = calculateTrends(it.value());
            }

            stats[paramCode] = paramStats;
        }

        emit statsCalculated(stats);
    }
    catch (const std::exception &e) {
        emit processingError(QString("Błąd podczas obliczania statystyk: %1").arg(e.what()));
    }
}

void DataProcessingThread::processSensorData(const QVariantList &rawSensorData)
{
    QMutexLocker locker(&m_mutex);

    try {
        if (rawSensorData.isEmpty()) {
            emit sensorDataProcessed(QVariantList());
            return;
        }

        QVariantList processedData = rawSensorData;

        // Dodanie dodatkowych informacji dla każdego sensora
        for (int i = 0; i < processedData.size(); ++i) {
            QVariantMap sensor = processedData[i].toMap();

            // Sprawdzenie, czy dane są aktualne (nie starsze niż 3 godziny)
            if (sensor.contains("lastDate")) {
                QString lastDateStr = sensor["lastDate"].toString();
                QDateTime lastDate = QDateTime::fromString(lastDateStr, Qt::ISODate);
                QDateTime now = QDateTime::currentDateTime();

                bool isRecent = lastDate.secsTo(now) < 3 * 3600; // 3 godziny
                sensor["isRecent"] = isRecent;

                // Dodanie informacji o czasie od ostatniego pomiaru
                int minutesSinceLastMeasurement = lastDate.secsTo(now) / 60;
                sensor["minutesSinceLastMeasurement"] = minutesSinceLastMeasurement;
            }

            // Klasyfikacja wartości parametrów według norm
            if (sensor.contains("paramFormula") && sensor.contains("value")) {
                QString formula = sensor["paramFormula"].toString();
                double value = sensor["value"].toDouble();

                // Dodanie klasyfikacji jakości (uproszczona logika)
                if (formula == "PM10") {
                    if (value <= 20) sensor["quality"] = "Bardzo dobra";
                    else if (value <= 50) sensor["quality"] = "Dobra";
                    else if (value <= 80) sensor["quality"] = "Umiarkowana";
                    else if (value <= 110) sensor["quality"] = "Dostateczna";
                    else if (value <= 150) sensor["quality"] = "Zła";
                    else sensor["quality"] = "Bardzo zła";
                }
                else if (formula == "PM2.5") {
                    if (value <= 13) sensor["quality"] = "Bardzo dobra";
                    else if (value <= 35) sensor["quality"] = "Dobra";
                    else if (value <= 55) sensor["quality"] = "Umiarkowana";
                    else if (value <= 75) sensor["quality"] = "Dostateczna";
                    else if (value <= 110) sensor["quality"] = "Zła";
                    else sensor["quality"] = "Bardzo zła";
                }
                // Dodaj inne parametry według potrzeb
            }

            processedData[i] = sensor;
        }

        emit sensorDataProcessed(processedData);
    }
    catch (const std::exception &e) {
        emit processingError(QString("Błąd podczas przetwarzania danych sensorów: %1").arg(e.what()));
    }
}

void DataProcessingThread::processAirQualityIndex(const QVariantMap &rawAqiData)
{
    QMutexLocker locker(&m_mutex);

    try {
        if (rawAqiData.isEmpty()) {
            emit airQualityIndexProcessed(QVariantMap());
            return;
        }

        QVariantMap processedAqi = rawAqiData;

        // Dodanie dodatkowych informacji do indeksu
        if (processedAqi.contains("stIndexLevel")) {
            QVariantMap indexLevel = processedAqi["stIndexLevel"].toMap();
            int indexValue = indexLevel["id"].toInt();

            // Dodanie rekomendacji na podstawie indeksu
            QString recommendation;
            switch (indexValue) {
            case 0:
                recommendation = "Jakość powietrza bardzo dobra. Idealne warunki do aktywności na zewnątrz.";
                break;
            case 1:
                recommendation = "Jakość powietrza dobra. Możesz bezpiecznie przebywać na zewnątrz.";
                break;
            case 2:
                recommendation = "Jakość powietrza umiarkowana. Rozważ ograniczenie aktywności na zewnątrz.";
                break;
            case 3:
                recommendation = "Jakość powietrza dostateczna. Osoby wrażliwe powinny ograniczyć przebywanie na zewnątrz.";
                break;
            case 4:
                recommendation = "Jakość powietrza zła. Unikaj przebywania na zewnątrz.";
                break;
            case 5:
                recommendation = "Jakość powietrza bardzo zła. Pozostań w pomieszczeniach z oczyszczonym powietrzem.";
                break;
            default:
                recommendation = "Brak danych o jakości powietrza.";
            }

            processedAqi["recommendation"] = recommendation;
        }

        // Sprawdzenie aktualności danych
        if (processedAqi.contains("stCalcDate")) {
            QString calcDateStr = processedAqi["stCalcDate"].toString();
            QDateTime calcDate = QDateTime::fromString(calcDateStr, Qt::ISODate);
            QDateTime now = QDateTime::currentDateTime();

            bool isRecent = calcDate.secsTo(now) < 3 * 3600; // 3 godziny
            processedAqi["isRecent"] = isRecent;

            int hoursSinceCalculation = calcDate.secsTo(now) / 3600;
            processedAqi["hoursSinceCalculation"] = hoursSinceCalculation;
        }

        emit airQualityIndexProcessed(processedAqi);
    }
    catch (const std::exception &e) {
        emit processingError(QString("Błąd podczas przetwarzania indeksu jakości powietrza: %1").arg(e.what()));
    }
}

void DataProcessingThread::filterStations(const QVariantList &stations, const QString &filterCriteria)
{
    QMutexLocker locker(&m_mutex);

    try {
        if (stations.isEmpty()) {
            emit stationsFiltered(QVariantList());
            return;
        }

        QVariantList filteredStations;

        // Przykładowa implementacja filtrowania
        for (const QVariant &stationVar : stations) {
            QVariantMap station = stationVar.toMap();

            // Filtrowanie po nazwie stacji
            if (!filterCriteria.isEmpty() && station.contains("stationName")) {
                QString stationName = station["stationName"].toString();
                if (stationName.contains(filterCriteria, Qt::CaseInsensitive)) {
                    filteredStations.append(station);
                }
            }
            // Jeśli brak kryteriów, dodaj wszystkie stacje
            else if (filterCriteria.isEmpty()) {
                filteredStations.append(station);
            }
        }

        emit stationsFiltered(filteredStations);
    }
    catch (const std::exception &e) {
        emit processingError(QString("Błąd podczas filtrowania stacji: %1").arg(e.what()));
    }
}

double DataProcessingThread::calculateMedian(QList<double> values)
{
    if (values.isEmpty()) return 0.0;

    int size = values.size();
    if (size % 2 == 0) {
        // Średnia z dwóch środkowych wartości
        return (values[size/2-1] + values[size/2]) / 2.0;
    } else {
        // Środkowa wartość
        return values[size/2];
    }
}

QVariantMap DataProcessingThread::calculateTrends(const QVariantList &data)
{
    QVariantMap trends;

    if (data.size() < 2) {
        trends["direction"] = "stable";
        trends["rate"] = 0.0;
        return trends;
    }

    // Zakładamy, że dane są posortowane chronologicznie
    // Obliczanie trendu na podstawie pierwszej i ostatniej wartości
    QVariantMap firstPoint = data.first().toMap();
    QVariantMap lastPoint = data.last().toMap();

    double firstValue = firstPoint["value"].toDouble();
    double lastValue = lastPoint["value"].toDouble();

    QDateTime firstTime = QDateTime::fromString(firstPoint["date"].toString(), Qt::ISODate);
    QDateTime lastTime = QDateTime::fromString(lastPoint["date"].toString(), Qt::ISODate);

    double hoursDiff = firstTime.secsTo(lastTime) / 3600.0;
    if (hoursDiff <= 0) {
        trends["direction"] = "stable";
        trends["rate"] = 0.0;
        return trends;
    }

    double change = lastValue - firstValue;
    double changeRate = change / hoursDiff; // zmiana na godzinę

    if (changeRate > 0.5) {
        trends["direction"] = "rising";
    } else if (changeRate < -0.5) {
        trends["direction"] = "falling";
    } else {
        trends["direction"] = "stable";
    }

    trends["rate"] = changeRate;
    return trends;
}
