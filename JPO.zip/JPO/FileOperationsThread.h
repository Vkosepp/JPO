#ifndef FILEOPERATIONSTHREAD_H
#define FILEOPERATIONSTHREAD_H

#include <QDir>
#include <QMutex>
#include <QObject>
#include <QString>
#include <QThread>
#include <QVariantList>
#include <QVariantMap>

class FileOperationsThread : public QObject
{
    Q_OBJECT

public:
    explicit FileOperationsThread(QObject *parent = nullptr);
    ~FileOperationsThread();

public slots:
    // Zapisywanie danych do pliku
    void saveDataToFile(const QString &filePath, const QVariantMap &dataToSave);

    // Wczytywanie danych z pliku
    void loadDataFromFile(const QString &filePath);

    // Listowanie zapisanych plików
    void listSavedFiles(const QString &directory = QString());

    // Usuwanie pliku
    void deleteFile(const QString &filePath);

    // Automatyczny backup danych
    void createBackup(const QVariantMap &dataToBackup);

    // Sprawdzenie istnienia pliku lub katalogu
    void checkFileExists(const QString &filePath);

    // Eksport danych do CSV
    void exportToCsv(const QString &filePath,
                     const QVariantList &dataToExport,
                     const QStringList &headers);
    void initialize();

signals:
    // Sygnały emitowane do głównego wątku
    void dataSaved(bool success, const QString &message, const QString &filePath);
    void dataLoaded(const QVariantMap &loadedData, bool success, const QString &message);
    void fileListReady(const QVariantList &fileList);
    void fileDeleted(bool success, const QString &message);
    void backupCreated(bool success, const QString &backupPath);
    void fileExistsResult(bool exists, const QString &filePath);
    void dataExported(bool success, const QString &message, const QString &filePath);
    void fileError(const QString &errorMessage);

private:
    QMutex m_mutex;
    QString m_defaultDirectory;

    // Metody pomocnicze
    QString ensureDirectoryExists(const QString &dirPath);
    QString generateBackupFileName() const;
    QString sanitizeFileName(const QString &fileName) const;
    bool isValidFilePath(const QString &filePath) const;
};

#endif // FILEOPERATIONSTHREAD_H
